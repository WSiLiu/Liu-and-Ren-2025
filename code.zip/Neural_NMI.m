function [MI,NMI] = Neural_NMI(neuralspikes1,neuralspikes2,connection1,connection2)
Res = [];Res1 = [];
for mm = 1:size(neuralspikes1,4)
    % for each situaion，spiking counts of each neuron is measured over situations
    for nn = 1:size(neuralspikes1,1)
        Res = neuralspikes1(nn,1,:,mm);
        Res1(nn,:,mm) = Res(:)';
    end 
end
Res = [];Res2 = [];
for mm = 1:size(neuralspikes2,4)
    % for each situaion,Spiking counts of each neuron is measured over situations
    for nn = 1:size(neuralspikes2,1)
        Res = neuralspikes2(nn,1,:,mm);
        Res2(nn,:,mm) = Res(:)';
    end 
end

bottom1 = min(Res2(:));top1 = max(Res2(:));
edge = (bottom1-0.5):1:(top1+0.5);% range of neural spiking counts
MI = zeros(1,1);NMI = zeros(1,1);
for mm = 1:size(neuralspikes1,4)
    % for each situaion,Spiking counts of each neuron is measured over situations
    for nn = 1:size(neuralspikes1,1)
        for nn1 = 1:size(neuralspikes2,1)
            x = Res1(nn,:,mm);
            x = x(:);
            y = Res2(nn1,:,mm);
            y = y(:);
            [mi, nmi] = mutual_info(x, y, edge);
            MI(nn,nn1,mm) = mi*double(connection1(nn,nn1)||connection2(nn1,nn));
            NMI(nn,nn1,mm) = nmi*double(connection1(nn,nn1)||connection2(nn1,nn));
        end
    end
end
end