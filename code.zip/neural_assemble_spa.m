function neural_assemble_spa(test_data,net,stimulus,j,L,T0)
%% reaction time


clear RT_mu;clear RT_std;% calculate averaged value and standard deviation of RT for each situation
for m1 = 1:size(stimulus,2)
  clear iden_time;
  iden_time = net.iden_t(m1,:);
  
  correction_radio(m1,1) = sum(double(iden_time>=0))/length(iden_time);
  plot(m1,iden_time,'o','color',[0.8,0.8,0.8]);hold on;
  RT_mu(m1,1) = mean(iden_time);
  RT_std(m1,1) = std(iden_time);
end
[h,p,ci,stats] = ttest(x,y);

figure;
errorbar(RT_mu,RT_std,'*','color',[0.1,0.1,0.1],'LineWidth',1);xlim([0 (size(stimulus,2)+1)]);ylim([-5 50]);
set (gca,'xtick',1:1:size(stimulus,2));

top1 = max(net.iden_t(:));top2 = 0;xrange2 = 0;figure;
fre = [];bins = 1:1:top1;
name1 = [];
for m1 = 1:size(stimulus,2)% frequency histogram of RT for each situation
    clear iden_time;
    iden_time = net.iden_t(m1,3:end);
    [fre(m1,:) ~] = hist(iden_time,bins);
    color = m1*[0.2 0.2 0.2];
    name2 = ['situation',num2str(m1)];
    name1 = [name1;name2];
    h1 = histogram(iden_time,bins,'Facecolor',color);hold on;
    top2 = max(top2,max(fre(m1,:))+10);
    xrange2 = max(xrange2,ceil(max(iden_time(:))+5));
end
ylim([0 top2]);legend(name1);xlim([0 xrange2]);
for n1 = 1:size(stimulus,2)
    clear aa;
    aa = ['correction radio in ',num2str(n1),' situation is ',num2str(correction_radio(n1))];
    disp(aa);
end

%% Calculting downstream neural spiking rates for each situation
T1 = T0/2;N_neuron = size(test_data{1,1}.Zt,1);

% test_data.Zt are ex. neural spiking trains
% test_data.Lt are in. neural spiking trains

% Stimulus-induced responses of ex. neurons
j = 1;clear Z_count_sti;
% count_sti for ex. neural spikes in stimulus duration;
for l_style = 1:size(stimulus,2)
    for l = 1:L
    Z = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron
              if test_data{1,l}.Zt(n,t) == 1
                Z(n,t-(j-1)*T0-T0-T1) = 1;
              end
      end
    end
    Z_count_sti(:,:,l,l_style) = Z;
    end
    j = 1+j;
end
 
j = 1;clear Z_count_pre;
% cout_pre for ex. neural spikes in pre-stimulus duration;
for l_style = 1:size(stimulus,2)
   for l = 1:L
    Z = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zt(n,t) == 1
             Z(n,t-(j-1)*T0-T0) = 1;
          end
      end
    end
    Z_count_pre(:,:,l,l_style) = Z;
   end
j = 1+j;
end

N_neuron_L = size(test_data{1,1}.Lt,1);
j = 1;clear L_count_sti;
% count_sti for in. neural spikes in stimulus duration;
for l_style = 1:size(stimulus,2)
    for l = 1:L
    L0 = zeros(N_neuron_L,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron_L
              if test_data{1,l}.Lt(n,t) == 1
                L0(n,t-(j-1)*T0-T0-T1) = 1;
              end
      end
    end
    L_count_sti(:,:,l,l_style) = L0;
    end
    j = 1+j;
end

j = 1;clear L_count_pre;
% count_pre for in. neural spikes in pre-stimulus duration;
for l_style = 1:size(stimulus,2)
   for l = 1:L
    L0 = zeros(N_neuron_L,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron_L
          if test_data{1,l}.Lt(n,t) == 1
             L0(n,t-(j-1)*T0-T0) = 1;
          end
      end
    end
    L_count_pre(:,:,l,l_style) = L0;
   end
j = 1+j;
end


% ex. and in. neural spiking rates
Z_rate_real = zeros(N_neuron,T1,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t = 1:T1
    for t1 = 1:T1
        for n = 1:N_neuron
            Z_rate_real(n,t,l,l_style) = Z_rate_real(n,t,l,l_style)+Z_count_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
  end
 end
end

Z_rate_pe = zeros(N_neuron,T1,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t = 1:T1
    for t1 = 1:T1
        for n = 1:N_neuron
            Z_rate_pe(n,t,l,l_style) = Z_rate_pe(n,t,l,l_style)+Z_count_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
  end
 end
end

L_rate_real = zeros(N_neuron_L,T1,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t = 1:T1
    for t1 = 1:T1
        for n = 1:N_neuron_L
            L_rate_real(n,t,l,l_style) = L_rate_real(n,t,l,l_style)+L_count_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
  end
 end
end

L_rate_pe = zeros(N_neuron_L,T1,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t = 1:T1
    for t1 = 1:T1
        for n = 1:N_neuron_L
            L_rate_pe(n,t,l,l_style) = L_rate_pe(n,t,l,l_style)+L_count_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
  end
 end
end


%% save and load neural spiking rates if necessary


% save('Z_rate_pe_spa','Z_rate_pe');save('Z_rate_real_spa','Z_rate_real');
% save('L_rate_pe_spa','L_rate_pe');save('L_rate_real_spa','L_rate_real');

% aa = load('Z_rate_pe_spa');Z_rate_pe = aa.Z_rate_pe;aa = load('Z_rate_real_spa');Z_rate_real = aa.Z_rate_real;
% aa = load('L_rate_pe_spa');L_rate_pe = aa.L_rate_pe;aa = load('L_rate_real_spa');L_rate_real = aa.L_rate_real;
%% neural variability quenching
% neural spiking complex
[Z_popucomplex_sti,Z_popucomplex_pre] = neural_groups_spiking_complex(Z_count_sti,Z_count_pre);
clear x;
x= 1:2;
figure;
for n_situation = 1:2
    clear y;
    y = [Z_popucomplex_pre(n_situation),Z_popucomplex_sti(n_situation)];
    plot(x,y,'o-','color',[0.3,0.3,0.3]*n_situation,'MarkerSize',15);hold on;
end
bottom = 0.95*min([Z_popucomplex_pre(:);Z_popucomplex_sti(:)]);
top = 1.05*max([Z_popucomplex_pre(:);Z_popucomplex_sti(:)]);
set(gca,'xlim',[0.5,2.5],'ylim',[bottom,top],'xtick',[]);
title('ex. neural responding complexity');

% Fano factor and SD of ex. neural population

Z_rate_pe_popu = sum(Z_rate_pe,1);
Z_rate_real_popu = sum(Z_rate_real,1);
clear Z_mean_real;clear Z_std_real;
for l_style = 1:size(stimulus,2)
  for t = 1:T1
   Z_mean_real(1,t,l_style) = mean(Z_rate_real_popu(1,t,:,l_style));
   Z_std_real(1,t,l_style) = std(Z_rate_real_popu(1,t,:,l_style));
   FanoZ_real(1,t,l_style) = (Z_std_real(1,t,l_style)^2)/Z_mean_real(1,t,l_style);
  end
end
clear Z_std_pe;
for l_style = 1:size(stimulus,2)
  for t = 1:T1
   Z_mean_pe(1,t,l_style) = mean(Z_rate_pe_popu(1,t,:,l_style));
   Z_std_pe(1,t,l_style) = std(Z_rate_pe_popu(1,t,:,l_style));
   FanoZ_pe(1,t,l_style) = (Z_std_pe(1,t,l_style)^2)/Z_mean_pe(1,t,l_style);
  end
end

% plot Fano factor and SD of ex. neural group
x = 1:(size(stimulus,2)*2*T1);y1 = [];
for n1 = 1:size(Z_std_pe,3)
    y1 = [y1,FanoZ_pe(:,:,n1),FanoZ_real(:,:,n1)];
end
figure;
plot(x,y1,'color',[0.3,0.3,0.3]);ylim([0.95*min(y1),1.05*max(y1)]);ylabel('Fano Factor');hold on;xlabel('time step');
for l_style = 1:size(stimulus,2)
    plot([T1+T0*(l_style-1),T1+T0*(l_style-1)],[0.95*min(y1),1.05*max(y1)],'--','color',[0.8,0.8,0.8]);hold on;
    plot([T0+T0*(l_style-1),T0+T0*(l_style-1)],[0.95*min(y1),1.05*max(y1)],'--','color',[0.8,0.8,0.8]);hold on;
end

x = 1:(size(stimulus,2)*2*T1);y1 = [];
for n1 = 1:size(Z_std_pe,3)
    y1 = [y1,Z_std_pe(:,:,n1),Z_std_real(:,:,n1)];
end
figure;
plot(x,y1,'color',[0.3,0.3,0.3]);ylim([0,1.2*max(y1)]);ylabel('SD');
ylim([0,1.2*max(y1)]);hold on;xlabel('time step');
for l_style = 1:size(stimulus,2)
    plot([T1+T0*(l_style-1),T1+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.8,0.8,0.8]);hold on;
    plot([T0+T0*(l_style-1),T0+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.8,0.8,0.8]);hold on;
end

% CV of spikes of ex. neurons
N = size(test_data{1,l}.Zt,1);
Z_ISI_real = zeros(N,T1,L,size(stimulus,2));
N_sti = size(stimulus,2);
[CV_pe,CV_real] = CV_spikes(Z_count_sti,Z_count_pre,N,T1,L,N_sti);

figure;aa = [];
for l_style = 1:size(stimulus,2)
   plot([0.5,2.5],[CV_pe(1,l_style),CV_real(1,l_style)],'-o','color',[0.3,0.3,0.3]*l_style,'MarkerSize',15);hold on
   aa = [aa;'situation',num2str(l_style)];
end
xlim([0,3]);title('CV of ISI of ex. neural group');
set(gca,'XTick',[0.5,1,2,2.5],'xticklabel',{ });
legend(aa);ylim([0.95*min(CV_real(:)),1.05*max(CV_pe(:))]);


%% neural sparse responses of ex. neural groups

clear sparseness_Z;
for n_neuron = 1:size(Z_count_sti,1)% for each neuron in the ex. group
    % a1 is neural spikes in 1st situation
    a1 = Z_count_sti(n_neuron,:,:,1);
    % a2 is neural spikes in 2nd situation
    a2 = Z_count_sti(n_neuron,:,:,2);
    % Z_rate_sti are spiking rate over time and
    % simulations
    Z_rate_sti(1) = mean(mean(a1,2),3);
    Z_rate_sti(2)= mean(mean(a2,2),3);
    if sum(Z_rate_sti)>0
       sparseness_Z(n_neuron) = (mean(Z_rate_sti)^2)/mean(Z_rate_sti.^2);
    else
       sparseness_Z(n_neuron) = 0;
    end
end

% plot neural sparseness of ex. neural group
clear a1;
xbin = 0:0.1:1;
[a0,b0] = hist(sparseness_Z(:),xbin);
a1 = a0./sum(a0);
b1 = b0;
figure;
b = bar(b1,a1,'FaceColor',[0.5,0.5,0.5]);
title('ex. neural responding sparseness')

%% stimulus-modulation of ex. neural responses and variability
% Stimulus modification of neural responses
stimulus_modification_response(Z_rate_real);

% Stimulus-induced neural variability
stimulus_induced_variability(Z_rate_real);

% stabiliby_neural of neural spikes in different situations

stabiliby_neural = [];
for n_situation = 1:size(Z_count_sti,4)
    for l = 1:size(Z_count_sti,3)
    stabiliby_neural(l,n_situation) = 0;
    neural_spikes = Z_count_sti(:,:,l,n_situation);
    [~,stabiliby_neural(l,n_situation)] = DVA_neuralspike(neural_spikes);
    end
end
for n_situation = 1:size(Z_count_sti,4)
    stabiliby_neural_mean(n_situation) = mean(stabiliby_neural(:,n_situation));
    stabiliby_neural_std(n_situation) = std(stabiliby_neural(:,n_situation));
end
figure;
x = [1,3];
for n_situation = 1:size(Z_count_sti,4)
    plot(x(n_situation),stabiliby_neural_mean(n_situation),'ok','MarkerSize',10);hold on;
end
errorbar(x,stabiliby_neural_mean,stabiliby_neural_std,'Color',[.7,.7,.7]);
set(gca,'xlim',[0 4],'xTick',[1,3],'xTickLabel',{'1','2'});
title('stabiliby of ex. neural spikes in situations');
figure;
boxplot(stabiliby_neural,'Color',[0.5,0.5,0.5]);
title('stabiliby of ex. neural spikes in situations');

clear h;clear p;
[h,p,ci,stats] = ttest2(stabiliby_neural(:,1),stabiliby_neural(:,2));
% [h,p]


% stability of clustering sets over training phase
stability = net.stability;
figure;
x = 1:size(stability,2);
for nn = 1:size(stability,1)
    clear stability0;
    stability0 = stability(nn,:);
    
    plot(x,stability0,'color',[0.3,0.3,0.3]*nn);hold on;

end
set(gca,'xlim',[0 size(stability,2)+1],'ylim',[0 1]);
legend({'situation 1','situation 2'});

% PCA of ex. neural responses in different situations
neuralpopulation_rate = []; % neural responses at each time step is variable
for n1 = 1:size(Z_rate_real,4) % for each situation
    for t = 1:size(Z_rate_real,2) % for each time step
        % neural population is averaged over simulation
        neuralpopulation_rate = [neuralpopulation_rate;mean(Z_rate_real(:,t,:,n1),3)'];
    end
end

[COEFF, SCORE, latent] = pca(neuralpopulation_rate); % COEFF is the coefficient in PCA
% novel variables are neuralpopulation_rate*COEFF describe the responses of
% the network at a given time step
save('COEFF','COEFF');
contri_intergra = sum(latent(1:3))/sum(latent)
PCA_tem_real0 = [];
for n1 = 1:size(Z_rate_real,4) % for each situation
    for n2 = 1:size(Z_rate_real,3) % for each simulation
        for t = 1:size(Z_rate_real,2) % for each time step
           PCA_tem_real0(:,t,n1,n2) = (Z_rate_real(:,t,n2,n1)' * COEFF(:,1:3))';
        end
    end
end
PCA_tem_pe0 = [];
for n1 = 1:size(Z_rate_pe,4) % for each situation
    for n2 = 1:size(Z_rate_pe,3) % for each simulation
        for t = 1:size(Z_rate_pe,2) % for each time step
           PCA_tem_pe0(:,t,n1,n2) = ((Z_rate_pe(:,t,n2,n1)') * COEFF(:,1:3))';
        end
    end
end
PCA_tem_pe = mean(PCA_tem_pe0,4);
PCA_tem_real = mean(PCA_tem_real0,4);
clear PCA_tem;
for n1 = 1:size(Z_rate_real,4) % for each situation
    PCA_tem(:,:,n1) = [PCA_tem_pe(:,:,n1),PCA_tem_real(:,:,n1)];
end
d0 = 0.48/size(PCA_tem,2)*[1 1 1];
figure;
for n1 = 1:size(Z_rate_real,4) % for each situation
    for t = 1:size(PCA_tem,2)-1
    x1 = PCA_tem(1,t,n1);x2 = PCA_tem(1,t+1,n1);
    x = [x1 x2];
    y1 = PCA_tem(2,t,n1);y2 = PCA_tem(2,t+1,n1);
    y = [y1 y2];
    z1 = PCA_tem(3,t,n1);z2 = PCA_tem(3,t+1,n1);
    z = [z1 z2];
    if t<=size(PCA_tem,2)/2 
        facecolor = [0.5,0.5,0.5]*(n1-1)+d0*t; % the pre-stimulus duration
        plot3(x1, y1, z1,'o','Markersize',5,'Color',[0.5,0.5,0.5]*(n1-1)+d0*t,'MarkerFaceColor',facecolor);hold on;
    else
        facecolor = [0.5,0.5,0.5]*(n1-1)+d0*t; % the stimulus-presented duration
        plot3(x1, y1, z1,'o','Markersize',10,'Color',[0.5,0.5,0.5]*(n1-1)+d0*t,'MarkerFaceColor',facecolor);hold on;
    end
    plot3(x, y, z,'-','LineWidth',5,'Color',[0.5,0.5,0.5]*(n1-1)+d0*t);hold on;
    end
end
grid on;
xlabel('PC1');ylabel('PC2');zlabel('PC3');

%% For downstream neural groups, their interactions are calculated through Pearson correlation coefficient

% interactions between pre-stimulus and stimulus-induced ex. neural responses
% X are stimulus-presented ex. neural responses 
% Y are pre-stimulus ex. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal0;clear Zpe0;clear Zreal1;clear Zpe1;
        % Zreal0 are the temporal neural populational responses in stimulus-presented duration
        Zreal0 = sum(Z_rate_real(:,t,:,l_style),1);
        Zreal0 = Zreal0(:);
        % Zpe0 are the temporal neural populational responses in pre-stimulus duration
        Zpe0 = sum(Z_rate_pe(:,t,:,l_style),1);
        Zpe0 = Zpe0(:);
        E_XY = mean(Zreal0.*Zpe0); % E(XY)
        E_Y2 = mean(Zpe0.^2); % E(Y^2)
        E_Y = mean(Zpe0);% EY
        E_X = mean(Zreal0);% EX
        Cov_Y_X_Y = E_XY - E_Y2 + (E_Y)^2 - E_X*E_Y;% cov(X-Y,Y)
        Cov_XY = cov(Zreal0,Zpe0);% matrix of cov(X,Y) 
        Var_X_Y = Cov_XY(1,1) + Cov_XY(2,2) - 2*Cov_XY(1,2);% var(X-Y)
        Var_Y = var(Zpe0);% var(Y)
        p(t,l_style) = Cov_Y_X_Y/sqrt(Var_X_Y*Var_Y);% p(X-Y,Y)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'situation ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('pre-stimulus and stimulus-induced ex. neural responses');

% interactions between stimulus-induced inhi. neural responses and ex. neural responses
% X are stimulus-presented ex. neural responses
% X1 are pre-stimulus ex. neural responses
% Y are stimulus-presented inhi. neural responses
% Y1 are pre-stimulus inhi. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal0;clear Zpe0;clear Zreal1;clear Zpe1;
        clear Lreal0;clear Lpe0;clear Lreal1;clear Lpe1;
        % Zreal0 are the temporal ex. neural populational responses in stimulus-presented duration
        Zreal0 = sum(Z_rate_real(:,t,:,l_style),1);
        Zreal0 = Zreal0(:);
        % Zpe0 are the temporal ex. neural populational responses in pre-stimulus duration
        Zpe0 = sum(Z_rate_pe(:,t,:,l_style),1);
        Zpe0 = Zpe0(:);
        % Lreal0 are the temporal inhi. neural populational responses in stimulus-presented duration
        Lreal0 = sum(L_rate_real(:,t,:,l_style),1);
        Lreal0 = Lreal0(:);
        % Lpe0 are the temporal inhi. neural populational responses in pre-stimulus duration
        Lpe0 = sum(L_rate_pe(:,t,:,l_style),1);
        Lpe0 = Lpe0(:);

        E_XY = mean(Zreal0.*Lreal0); %E(XY)
        E_XY1 = mean(Zreal0.*Lpe0); %E(XY1)
        E_X1Y = mean(Zpe0.*Lreal0); %E(X1Y)
        E_X1Y1 = mean(Zpe0.*Lpe0); %E(X1Y1)

        E_Z1Z2 = E_XY - E_XY1 - E_X1Y + E_X1Y1; % E(Z1Z2)

        EZ1 = mean(Zreal0) - mean(Zpe0); %E(Z1)
        EZ2 = mean(Lreal0) - mean(Lpe0); %E(Z2)

        Cov_Z1Z2 = E_Z1Z2 - EZ1*EZ2; %COV(Z1,Z2)

        Cov_Z1 = cov(Zreal0,Zpe0); % matrix of Zreal0 and Zpe0
        Var_Z1 = Cov_Z1(1,1) + Cov_Z1(2,2) - 2*Cov_Z1(1,2);% var(X-X1)

        Cov_Z2 = cov(Lreal0,Lpe0); % matrix of Lreal0 and Lpe0
        Var_Z2 = Cov_Z2(1,1) + Cov_Z2(2,2) - 2*Cov_Z2(1,2);% var(Y-Y1)

        p(t,l_style) = Cov_Z1Z2/sqrt(Var_Z1*Var_Z2);% p(X-X1,Y-Y1)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'situation ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('stimulus-induced ex. and inhi. neural responses');

% interactions between stimulus-induced VIP inhi. neural responses and ex. neural responses
% X are stimulus-presented ex. neural responses
% X1 are pre-stimulus ex. neural responses
% Y are stimulus-presented VIP inhi. neural responses
% Y1 are pre-stimulus VIP inhi. neural responses


p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal0;clear Zpe0;clear Zreal1;clear Zpe1;
        clear Lreal0;clear Lpe0;clear Lreal1;clear Lpe1;
        % Zreal0 are the temporal ex. neural populational responses in stimulus-presented duration
        Zreal0 = sum(Z_rate_real(:,t,:,l_style),1);
        Zreal0 = Zreal0(:);
        % Zpe0 are the temporal ex. neural populational responses in pre-stimulus duration
        Zpe0 = sum(Z_rate_pe(:,t,:,l_style),1);
        Zpe0 = Zpe0(:);
        % Lreal0 are the temporal VIP inhi. neural populational responses in stimulus-presented duration
        Vip_neuron = find(double(net.VIP == 1));
        Lreal0 = sum(L_rate_real(Vip_neuron(:),t,:,l_style),1);
        Lreal0 = Lreal0(:);
        % Lpe0 are the temporal VIP inhi. neural populational responses in pre-stimulus duration
        Lpe0 = sum(L_rate_pe(Vip_neuron(:),t,:,l_style),1);
        Lpe0 = Lpe0(:);

        E_XY = mean(Zreal0.*Lreal0); %E(XY)
        E_XY1 = mean(Zreal0.*Lpe0); %E(XY1)
        E_X1Y = mean(Zpe0.*Lreal0); %E(X1Y)
        E_X1Y1 = mean(Zpe0.*Lpe0); %E(X1Y1)

        E_Z1Z2 = E_XY - E_XY1 - E_X1Y + E_X1Y1; % E(Z1Z2)

        EZ1 = mean(Zreal0) - mean(Zpe0); %E(Z1)
        EZ2 = mean(Lreal0) - mean(Lpe0); %E(Z2)

        Cov_Z1Z2 = E_Z1Z2 - EZ1*EZ2; %COV(Z1,Z2)

        Cov_Z1 = cov(Zreal0,Zpe0); % matrix of Zreal0 and Zpe0
        Var_Z1 = Cov_Z1(1,1) + Cov_Z1(2,2) - 2*Cov_Z1(1,2);% var(X-X1)

        Cov_Z2 = cov(Lreal0,Lpe0); % matrix of Lreal0 and Lpe0
        Var_Z2 = Cov_Z2(1,1) + Cov_Z2(2,2) - 2*Cov_Z2(1,2);% var(Y-Y1)

        p(t,l_style) = Cov_Z1Z2/sqrt(Var_Z1*Var_Z2);% p(X-X1,Y-Y1)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'situation ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('stimulus-induced ex. and VIP inhi. neural responses');


% interactions between stimulus-induced VIP inhi. and other inhi. neural responses
% X are stimulus-presented VIP inhi. neural responses
% X1 are pre-stimulus VIP inhi. neural responses
% Y are stimulus-presented other inhi. neural responses
% Y1 are pre-stimulus other inhi. neural responses

p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Lreal0;clear Lpe0;clear Lreal1;clear Lpe1;
        clear LVIPreal0;clear LVIPpe0;clear LVIPreal1;clear LVIPpe1;

        % LVIPreal0 are the temporal VIP inhi. neural populational responses in stimulus-presented duration
        Vip_neuron = find(double(net.VIP == 1));
        LVIPreal0 = sum(L_rate_real(Vip_neuron(:),t,:,l_style),1);
        LVIPreal0 = LVIPreal0(:);
        % LVIPpe0 are the temporal VIP inhi. neural populational responses in pre-stimulus duration
        LVIPpe0 = sum(L_rate_pe(Vip_neuron(:),t,:,l_style),1);
        LVIPpe0 = LVIPpe0(:);
        % Lreal0 are the temporal other inhi. neural populational responses in stimulus-presented duration
        Other_neuron = find(double(net.VIP ~= 1));
        Lreal0 = sum(L_rate_real(Other_neuron(:),t,:,l_style),1);
        Lreal0 = Lreal0(:);
        % Lpe0 are the temporal other inhi. neural populational responses in pre-stimulus duration
        Lpe0 = sum(L_rate_pe(Other_neuron(:),t,:,l_style),1);
        Lpe0 = Lpe0(:);

        E_XY = mean(LVIPreal0.*Lreal0); %E(XY)
        E_XY1 = mean(LVIPreal0.*Lpe0); %E(XY1)
        E_X1Y = mean(LVIPpe0.*Lreal0); %E(X1Y)
        E_X1Y1 = mean(LVIPpe0.*Lpe0); %E(X1Y1)

        E_Z1Z2 = E_XY - E_XY1 - E_X1Y + E_X1Y1; % E(Z1Z2)

        EZ1 = mean(LVIPreal0) - mean(LVIPpe0); %E(Z1)
        EZ2 = mean(Lreal0) - mean(Lpe0); %E(Z2)

        Cov_Z1Z2 = E_Z1Z2 - EZ1*EZ2; %COV(Z1,Z2)

        Cov_Z1 = cov(LVIPreal0,LVIPpe0); % matrix of LVIPreal0 and LVIPpe0
        Var_Z1 = Cov_Z1(1,1) + Cov_Z1(2,2) - 2*Cov_Z1(1,2);% var(X-X1)

        Cov_Z2 = cov(Lreal0,Lpe0); % matrix of Lreal0 and Lpe0
        Var_Z2 = Cov_Z2(1,1) + Cov_Z2(2,2) - 2*Cov_Z2(1,2);% var(Y-Y1)

        p(t,l_style) = Cov_Z1Z2/sqrt(Var_Z1*Var_Z2);% p(X-X1,Y-Y1)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'situation ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('stimulus-induced VIP inhi. and other inhi. neural responses');


% interactions between pre-stimulus VIP inhi. neural responses and stimulus-induced ex. neural responses
% X are stimulus-presented ex. neural responses
% X1 are pre-stimulus ex. neural responses
% Y are pre-stimulus VIP inhi. neural responses


p = zeros(T1,size(stimulus,2));
for l_style = 1:size(stimulus,2)
    for t = 1:T1
        clear Zreal0;clear Zpe0;clear Zreal1;clear Zpe1;
        clear Lpe0;clear Lpe1;

        % Zreal0 are the temporal neural populational responses in stimulus-presented duration
        Zreal0 = sum(Z_rate_real(:,t,:,l_style),1);
        Zreal0 = Zreal0(:);
        % Zpe0 are the temporal neural populational responses in pre-stimulus duration
        Zpe0 = sum(Z_rate_pe(:,t,:,l_style),1);
        Zpe0 = Zpe0(:);

        % Lpe0 are the temporal VIP inhi. neural populational responses in pre-stimulus duration
        Vip_neuron = find(double(net.VIP == 1));
        Lpe0 = sum(L_rate_pe(Vip_neuron(:),t,:,l_style),1);
        Lpe0 = Lpe0(:);

        E_XY = mean(Zreal0.*Lpe0); % E(XY)
        E_X1Y = mean(Zpe0.*Lpe0); % E(X1Y)
        E_X = mean(Zreal0);% EX
        E_X1 = mean(Zpe0); % E(X1)
        E_Y = mean(Lpe0);% EY

        Cov_Z1Y = E_XY-E_X1Y-E_X*E_Y+E_X1*E_Y; % cov(X-X1,Y)

        Var_Y = var(Lpe0);% var(Y)
        Cov_Z1 = cov(Zreal0,Zpe0); % matrix of Zreal0 and Zpe0
        Var_Z1 = Cov_Z1(1,1) + Cov_Z1(2,2) - 2*Cov_Z1(1,2);% var(X-X1)
        p(t,l_style) = Cov_Z1Y/sqrt(Var_Z1*Var_Y);% p(X-Y,Y)
    end
end
figure;aa = [];
for l_style = 1:size(stimulus,2)
    X = 1:T1;
    plot(X,p(:,l_style),'color',[0.3,0.3,0.3]*l_style);
    hold on;
    aa = [aa;'situation ',num2str(l_style)];
end
legend(aa);ylabel('Pearson correlation coefficient');
xlabel('time step');title('pre-stimulus VIP inhi. neural responses and stimulus-induced ex. neural responses');


% neural contributions in identificaitons
% ex. and in. neural spiking rates
Z_rate_real_contri = zeros(N_neuron,L,size(stimulus,2));
Z_spike_real_contri = zeros(N_neuron,L,size(stimulus,2));
for l_style = 1:size(stimulus,2) % for each situation
 for l = 1:L % for each simulation
  clear T2;T2 = net.iden_t(l_style,l);
  Z_spike_real_contri(:,l,l_style) = Z_count_sti(:,T2,l,l_style); % neural spikes at first correct identifications
  for t = 1:T2
   % neural spiking rates at first correct identifications
   Z_rate_real_contri(:,l,l_style) = (Z_rate_real_contri(:,l,l_style) + Z_count_sti(:,t,l,l_style))*exp(-1/20); 
  end
 end
end

clear Z_cluster;
for m = 1:size(Z_count_sti,4) % select clustering sets assotiated with 3rd group
    clear cluster0
    cluster0 = net.action{1,m};
    Z_cluster(:,:,m) = cluster0;
end

Z_distance = zeros(size(Z_count_sti,1)*2,size(Z_count_sti,4));
Z_contri = Z_distance;
Z_distance_spike = zeros(size(Z_count_sti,1),size(Z_count_sti,4));
Z_contri_spike = Z_distance_spike;
Z_distance_rate = Z_distance_spike;
Z_contri_rate = Z_distance_rate;

% distance induced by neural group in inference to different situations
for m = 1:size(Z_count_sti,4)% for each situation
 for ll = 1:size(Z_count_sti,3)% for each simulation
     clear Z_distance0;clear Z_distance_spike0;clear Z_distance_rate0;
     for v = 1:size(Z_cluster,2) % for each vector in each clustering martix
         Z_distance0(:,v) = [Z_spike_real_contri(:,ll,m);Z_rate_real_contri(:,ll,m)] - Z_cluster(:,v,m);
         Z_distance_spike0(:,v) = Z_distance0(1:size(Z_count_sti,1),v);
         Z_distance_rate0(:,v) = Z_distance0(1+size(Z_count_sti,1):end,v);
     end
     Z_distance(:,m) = Z_distance(:,m) + sum((Z_distance0.^2),2);
     Z_distance_spike(:,m) = Z_distance_spike(:,m) + sum((Z_distance_spike0.^2),2);
     Z_distance_rate(:,m) = Z_distance_rate(:,m) + sum((Z_distance_rate0.^2),2);
 end
end

% with the Maximum of distance, neural contributions in inference are
% measured
clear max_distance;clear min_distance;
for m = 1:size(Z_distance,2)
    max_distance(m) = max(Z_distance(:,m));
    min_distance(m) = min(Z_distance(:,m));
    Z_contri(:,m) = 1 - (Z_distance(:,m)-min_distance(m))/(max_distance(m)-min_distance(m));
    Z_contri_spike(:,m) = 1 - (Z_distance_spike(:,m)-min_distance(m))/(max_distance(m)-min_distance(m));
    Z_contri_rate(:,m) = 1 - (Z_distance_rate(:,m)-min_distance(m))/(max_distance(m)-min_distance(m));
end

clear h;clear p;
[h,p,ci,stats] = ttest2(Z_contri(:,1),Z_contri(:,2));
% [h,p]

% plot neural contributions in inference at different vertical locations
clear contr_mu;clear contr_std;% average and standard variance of contributions in situations
for m = 1:size(Z_count_sti,4)% for each situation
    contr_mu(m) = mean(Z_contri(:,m));contr_std(m) = std(Z_contri(:,m));
end
clear contr_spike_mu;clear contr_spike_std;% average and standard variance of spike-based contributions in situations
for m = 1:size(Z_count_sti,4)% for each situation
    contr_spike_mu(m) = mean(Z_contri_spike(:,m));contr_spike_std(m) = std(Z_contri_spike(:,m));
end
clear contr_rate_mu;clear contr_rate_std;% average and standard variance of rate-based contributions in situations
for m = 1:size(Z_count_sti,4)% for each situation
    contr_rate_mu(m) = mean(Z_contri_rate(:,m));contr_rate_std(m) = std(Z_contri_rate(:,m));
end

figure;
hindles = barweb(contr_mu,contr_std,1);
title('Neural contributions in identifications');
figure;
hindles = barweb(contr_spike_mu,contr_spike_std,1);
title('Spike-based contributions in identifications');
figure;
hindles = barweb(contr_rate_mu,contr_rate_std,1);
title('Rate-based contributions in identifications');

%% Different vertical locations
% VIP inhi. and ex. neural responses 
vertical_location = net.Ve_location;
% situations of different vertical locations are selected
Vertical_location_situation = cell(size(vertical_location,1),5);
for n_situation = 1:size(vertical_location,1)
    for n_ver_loca = 1:5 % for each vertical location
        clear seleted_situation;
        seleted_situation = find(vertical_location(n_situation,:) == n_ver_loca);
        Vertical_location_situation{n_situation,n_ver_loca} = seleted_situation;
    end
end

% temporal interaction between stimulus-induced VIP inhi. and stimulus-induced ex. neural responses
% at different vertical locations

p = zeros(T1,size(Vertical_location_situation,1),size(Vertical_location_situation,2));
for n1 = 1:size(Vertical_location_situation,1) % n1 is situation
    for n2 = 1:size(Vertical_location_situation,2) % n2 is vertical location
        clear situation;clear L_count0;clear L_rate0;clear L_rate1;
        situation = Vertical_location_situation{n1,n2};
        for t = 1:T1
        clear Zreal0;clear Zpe0;clear Zreal1;clear Zpe1;
        clear Lreal0;clear Lpe0;clear Lreal1;clear Lpe1;
        % Zreal0 are the temporal ex. neural populational responses in stimulus-presented duration
        Zreal0 = sum(Z_rate_real(:,t,situation,n1),1);
        Zreal0 = Zreal0(:);
        % Zpe0 are the temporal ex. neural populational responses in pre-stimulus duration
        Zpe0 = sum(Z_rate_pe(:,t,situation,n1),1);
        Zpe0 = Zpe0(:);
        % Lreal0 are the temporal VIP inhi. neural populational responses in stimulus-presented duration
        Vip_neuron = find(double(net.VIP == 1));
        Lreal0 = sum(L_rate_real(Vip_neuron(:),t,situation,n1),1);
        Lreal0 = Lreal0(:);
        
        % Lpe0 are the temporal VIP inhi. neural populational responses in pre-stimulus duration
        Lpe0 = sum(L_rate_pe(Vip_neuron(:),t,situation,n1),1);
        Lpe0 = Lpe0(:);
        [max(Lreal0),max(Lpe0)];
        E_XY = mean(Zreal0.*Lreal0); %E(XY)
        E_XY1 = mean(Zreal0.*Lpe0); %E(XY1)
        E_X1Y = mean(Zpe0.*Lreal0); %E(X1Y)
        E_X1Y1 = mean(Zpe0.*Lpe0); %E(X1Y1)
        E_Z1Z2 = E_XY - E_XY1 - E_X1Y + E_X1Y1; % E(Z1Z2)
        EZ1 = mean(Zreal0) - mean(Zpe0); %E(Z1)
        EZ2 = mean(Lreal0) - mean(Lpe0); %E(Z2)
        Cov_Z1Z2 = E_Z1Z2 - EZ1*EZ2; %COV(Z1,Z2)
        Cov_Z1 = cov(Zreal0,Zpe0); % matrix of Zreal0 and Zpe0
        Var_Z1 = Cov_Z1(1,1) + Cov_Z1(2,2) - 2*Cov_Z1(1,2);% var(X-X1)
        Cov_Z2 = cov(Lreal0,Lpe0); % matrix of Lreal0 and Lpe0
        Var_Z2 = Cov_Z2(1,1) + Cov_Z2(2,2) - 2*Cov_Z2(1,2);% var(Y-Y1)
        p(t,n1,n2) = Cov_Z1Z2/sqrt(Var_Z1*Var_Z2);% p(X-X1,Y-Y1)
        end
    end
end

top = 1.2*max(p(:));bottom = min(p(:));
for nn1 = 1:size(p,2) % for each situation
    figure;
    aa = [];
    for nn2 = 1:size(p,3)% for each vertical location
        clear p0;
        p0 = p(:,nn1,nn2);
        x = 1:size(p0,1);
        plot(x,p0','Color',[0.15,0.15,0.15]*nn2);hold on
        aa = [aa;'location ',num2str(nn2)];
    end
    legend(aa);
    set(gca,'ylim',[bottom top]);ylabel('Pearson correlation coefficient');
    title(['stimulus-induced ex. and VIP inhi. neural responses in situation ' num2str(nn1)]);
end

% Fano factor

Z_rate_pe_popu = sum(Z_rate_pe,1);
Z_rate_real_popu = sum(Z_rate_real,1);
clear Z_mean_real_ver;clear Z_std_real_ver;clear FanoZ_real_ver;
clear Z_std_pe_ver;clear Z_mean_pe_ver;clear FanoZ_pe_ver;
for l_style = 1:size(stimulus,2)
 for n2 = 1:size(Vertical_location_situation,2) % n2 is vertical location
  clear situation;
  situation = Vertical_location_situation{n1,n2};
  for t = 1:T1
   Z_mean_real_ver(1,t,n2,l_style) = mean(Z_rate_real_popu(1,t,situation,l_style));
   Z_std_real_ver(1,t,n2,l_style) = std(Z_rate_real_popu(1,t,situation,l_style));
   FanoZ_real_ver(1,t,n2,l_style) = (Z_std_real_ver(1,t,n2,l_style)^2)/Z_mean_real_ver(1,t,n2,l_style);
   Z_mean_pe_ver(1,t,n2,l_style) = mean(Z_rate_pe_popu(1,t,situation,l_style));
   Z_std_pe_ver(1,t,n2,l_style) = std(Z_rate_pe_popu(1,t,situation,l_style));
   FanoZ_pe_ver(1,t,n2,l_style) = (Z_std_pe_ver(1,t,n2,l_style)^2)/Z_mean_pe_ver(1,t,n2,l_style);
  end
 end
end

for l_style = 1:size(stimulus,2)
  figure;
  aa = [];
  X = 1:(2*T1);
  for n2 = 1:size(Vertical_location_situation,2) % n2 is vertical location
      % clear situation;
      % situation = Vertical_location_situation{n1,n2};
      clear Fano0;
      Fano0 = [FanoZ_pe_ver(1,:,n2,l_style),FanoZ_real_ver(1,:,n2,l_style)];
      plot(X,Fano0,'Color',[0.15,0.15,0.15]*n2);hold on;
      aa = [aa;'location ',num2str(n2)];
  end
  legend(aa);
end

% PCA of ex. neural responses at different vertical locations
contri_intergra = sum(latent(1:2))/sum(latent)
PCA_tem_locations_real0 = [];
PCA_tem_locations_pe0 = [];
for n1 = 1:size(Z_rate_real,4) % for each situation
    for n2 = 1:size(Vertical_location_situation,2) % n2 is vertical location
        clear situation;
        situation = Vertical_location_situation{n1,n2};
        for nn2 = 1:length(situation)
         for t = 1:size(Z_rate_real,2) % for each time step
           PCA_tem_locations_real0(:,t,n1,n2,nn2) = (Z_rate_real(:,t,situation(nn2),n1)' * COEFF(:,1:2))';
           PCA_tem_locations_pe0(:,t,n1,n2,nn2) = ((Z_rate_pe(:,t,situation(nn2),n1)') * COEFF(:,1:2))';
         end
        end
    end
end
PCA_tem_pe = mean(PCA_tem_locations_pe0,5);
PCA_tem_real = mean(PCA_tem_locations_real0,5);
clear PCA_tem_locations;
for n1 = 1:size(Z_rate_real,4) % for each situation
    for n2 = 1:size(Vertical_location_situation,2) % n2 is vertical location
     PCA_tem_locations(:,:,n1,n2) = PCA_tem_real(:,:,n1,n2);
    end
end

d0 = 0.195/(size(PCA_tem_locations,2))*[1 1 1];
for n1 = 1:size(Z_rate_real,4) % for each situation
    figure;
    for n22 = 1:size(Vertical_location_situation,2) % n22 is vertical location
     for t = 1:size(PCA_tem_locations,2)-1
         x1 = PCA_tem_locations(1,t,n1,n22);x2 = PCA_tem_locations(1,t+1,n1,n22);
         x = [x1 x2];
         y1 = PCA_tem_locations(2,t,n1,n22);y2 = PCA_tem_locations(2,t+1,n1,n22);
         y = [y1 y2];
         facecolor = [0.2,0.2,0.2]*(n22-1)+d0*t; % the stimulus-presented duration
         plot(x1, y1,'o','Markersize',10,'Color',facecolor,'MarkerFaceColor',facecolor);hold on;
         plot(x, y,'-','LineWidth',5,'Color',facecolor);hold on;
     end
    end
    grid on;
    xlabel('PC1');ylabel('PC2');
end

% network performance
for m1 = 1:size(stimulus,2)
  figure;
  for n2 = 1:size(Vertical_location_situation,2) % n2 is vertical location
  clear situation;
  situation = Vertical_location_situation{n1,n2};
  clear iden_time;
  iden_time = net.iden_t(m1,situation(:)');
  color = [0.15 0.15 0.15]*n2;
  plot(n2,mean(iden_time),'o','Color',color,'markerfacecolor',color,'MarkerSize',15);hold on;
  errorbar(n2,mean(iden_time),std(iden_time),'Color',[.7,.7,.7]);hold on;
  end
  set(gca,'xLim',[0 6],'xTick',[1,2,3,4,5],'xTickLabel',{'1','2','3','4','5'});
  title('Performance with different strength of VIP inhi. neural firing')
end

% contribution of neurons in identification
clear Z_cluster;
for m = 1:size(Z_count_sti,4) % select clustering sets assotiated with 3rd group
    clear cluster0
    cluster0 = net.action{1,m};
    Z_cluster(:,:,m) = cluster0;
end

Z_distance = zeros(size(Z_count_sti,1)*2,size(Z_count_sti,4));
Z_contri = Z_distance;
clear Z_spike_overtime;
Z_spike_overtime = sum(Z_count_sti,2);
clear Z_spiking;clear Z_spiking_overtime;
Z_spiking = zeros(size(Z_count_sti));
for n1 = 1:size(Z_count_sti,4) % for each situation
    for l = 1:size(Z_count_sti,3) % for each simulation
        for t = 1:size(Z_count_sti,2)
            t1 = max(t-1,1);
            Z_spiking(:,t1,l,n1) = (Z_spiking(:,t1,l,n1) + Z_count_sti(:,t,l,n1))*exp(-1/20);
        end
    end
end
Z_spiking_overtime = sum(Z_spiking,2);

% distance induced by neural group in inference to different situations
for m = 1:size(Z_count_sti,4)% for each situation
 for ll = 1:size(Z_count_sti,3)% for each simulation
     clear Z_distance0
     for t = 1:size(Z_cluster,2)   
         Z_distance0(:,t) = [Z_spike_overtime(:,1,ll,m);Z_spiking_overtime(:,1,ll,m)] - Z_cluster(:,t,m);
     end
     Z_distance(:,m) = Z_distance(:,m) + sum((Z_distance0.^2),2);
 end
end

% with the Maximum of distance, neural contributions in inference are
% measured
Z_contri = zeros(size(Z_distance));
clear max_distance;clear min_distance;
for m = 1:size(Z_distance,2)
    max_distance(m) = max(Z_distance(:,m));
    min_distance(m) = min(Z_distance(:,m));
    Z_contri(:,m) = 1 - (Z_distance(:,m)-min_distance(m))/(max_distance(m)-min_distance(m));
end

% plot neural contributions in inference at different vertical locations
clear contr_mu;clear contr_std;% average and standard variance of contributions in situations
for m = 1:size(Z_count_sti,4)% for each situation
    for n1 = 1:size(Vertical_location_situation,2) % for each vertical location
      clear situation;
      situation = Vertical_location_situation{m,n1};
      contr_mu(m,n1) = mean(Z_contri(situation,m));contr_std(m,n1) = std(Z_contri(situation,m));
    end
end

% neural contributions in two situations
% average and standard variance of contributions in situations

figure;
hindles = barweb(contr_mu,contr_std,1);
title('Neural contributions in identifications at locations');

%% different strengths of VIP inhi. neural firing

Vip_neuron = find(double(net.VIP == 1));
clear VIPL_rate;
for n1 = 1:size(L_rate_real,4) % for each situation
    for n2 = 1:size(L_rate_real,3) % for each simulation
     VIPL_rate(n2,n1) = sum(sum(L_rate_real(Vip_neuron(:),:,n2,n1),2),1); % empirical distribution of VIP inhi. neural firing
    end
end
clear mid_rate; % empirical median of VIP inhi. neural firing in different situations
for n1 = 1:size(L_rate_real,4) % for each situation
    clear f;clear y;
    % f is the Empirical Cumulative Distribution Function
    % y is the value of VIP inhi. neural firing
    [f,y] = ecdf(VIPL_rate(:,n1)); 
    if ~isempty(find(f==0.5))
        % find the component in y correspond to 0.5 of ECDF
        mid_rate(n1) = y(find(f==0.5)); 
    else
        % or calculate the averaged value of components in y close to 0.5 of ECDF
        clear comp1;clear comp2;
        comp1 = max(find(f<0.5));
        comp2 = min(find(f>0.5));
        mid_rate(n1) = (y(comp1) + y(comp2))/2;
    end
end

VIP_neural_stregth = cell(2,2);
for n_situation = 1:size(VIPL_rate,2) % for each situation
    little = [];large = [];
    for n_simulation = 1:size(VIPL_rate,1) % for each simulation
        if VIPL_rate(n_simulation,n_situation) >= mid_rate(n_situation)
           large = [large;n_simulation];
        else
           little = [little;n_simulation];
        end
    end
    VIP_neural_stregth{n_situation,1} = little;
    VIP_neural_stregth{n_situation,2} = large;
end

% temporal interaction between stimulus-induced VIP inhi. and stimulus-induced ex. neural responses
% at different VIP responding strengths

p = zeros(T1,size(VIP_neural_stregth,1),size(VIP_neural_stregth,2));
for n1 = 1:size(VIP_neural_stregth,1) % n1 is situation
    for n2 = 1:size(VIP_neural_stregth,2) % n2 is responding strength
        clear situation;clear L_count0;clear L_rate0;clear L_rate1;
        situation = VIP_neural_stregth{n1,n2};
        for t = 1:T1
        clear Zreal0;clear Zpe0;clear Zreal1;clear Zpe1;
        clear Lreal0;clear Lpe0;clear Lreal1;clear Lpe1;
        % Zreal0 are the temporal ex. neural populational responses in stimulus-presented duration
        Zreal0 = sum(Z_rate_real(:,t,situation,n1),1);
        Zreal0 = Zreal0(:);
        % Zpe0 are the temporal ex. neural populational responses in pre-stimulus duration
        Zpe0 = sum(Z_rate_pe(:,t,situation,n1),1);
        Zpe0 = Zpe0(:);
        % Lreal0 are the temporal VIP inhi. neural populational responses in stimulus-presented duration
        Vip_neuron = find(double(net.VIP == 1));
        Lreal0 = sum(L_rate_real(Vip_neuron(:),t,situation,n1),1);
        Lreal0 = Lreal0(:);
        
        % Lpe0 are the temporal VIP inhi. neural populational responses in pre-stimulus duration
        Lpe0 = sum(L_rate_pe(Vip_neuron(:),t,situation,n1),1);
        Lpe0 = Lpe0(:);
        [max(Lreal0),max(Lpe0)];
        E_XY = mean(Zreal0.*Lreal0); %E(XY)
        E_XY1 = mean(Zreal0.*Lpe0); %E(XY1)
        E_X1Y = mean(Zpe0.*Lreal0); %E(X1Y)
        E_X1Y1 = mean(Zpe0.*Lpe0); %E(X1Y1)
        E_Z1Z2 = E_XY - E_XY1 - E_X1Y + E_X1Y1; % E(Z1Z2)

        EZ1 = mean(Zreal0) - mean(Zpe0); %E(Z1)
        EZ2 = mean(Lreal0) - mean(Lpe0); %E(Z2)
        Cov_Z1Z2 = E_Z1Z2 - EZ1*EZ2; %COV(Z1,Z2)
        Cov_Z1 = cov(Zreal0,Zpe0); % matrix of Zreal0 and Zpe0
        Var_Z1 = Cov_Z1(1,1) + Cov_Z1(2,2) - 2*Cov_Z1(1,2);% var(X-X1)
        Cov_Z2 = cov(Lreal0,Lpe0); % matrix of Lreal0 and Lpe0
        Var_Z2 = Cov_Z2(1,1) + Cov_Z2(2,2) - 2*Cov_Z2(1,2);% var(Y-Y1)
        p(t,n1,n2) = Cov_Z1Z2/sqrt(Var_Z1*Var_Z2);% p(X-X1,Y-Y1)

        end
    end
end

top = 1.2*max(p(:));bottom = min(p(:));
for nn1 = 1:size(p,2) % for each situation
    figure;
    aa = [];
    for nn2 = 1:size(p,3)% for each strength
        clear p0;
        p0 = p(:,nn1,nn2);
        x = 1:size(p0,1);
        plot(x,p0','Color',[0.4,0.4,0.4]*nn2);hold on;
        if nn2 == 1
           aa = [aa;'Little responding strength'];
        else
           aa = [aa;'Large  responding strength'];
        end
    end
    legend(aa);
    set(gca,'ylim',[bottom top]);ylabel('Pearson correlation coefficient');
    title(['stimulus-induced ex. and VIP inhi. neural responses in situation ' num2str(nn1)]);
end

% Fano factor

Z_rate_pe_popu = sum(Z_rate_pe,1);
Z_rate_real_popu = sum(Z_rate_real,1);
clear Z_mean_real_ver;clear Z_std_real_ver;clear FanoZ_real_ver;
clear Z_std_pe_ver;clear Z_mean_pe_ver;clear FanoZ_pe_ver;
for n1 = 1:size(stimulus,2)
 for n2 = 1:size(VIP_neural_stregth,2) % n2 is responding strength
  clear situation;
  situation = VIP_neural_stregth{n1,n2};
  for t = 1:T1
   Z_mean_real_ver(1,t,n2,n1) = mean(Z_rate_real_popu(1,t,situation,n1));
   Z_std_real_ver(1,t,n2,n1) = std(Z_rate_real_popu(1,t,situation,n1));
   FanoZ_real_ver(1,t,n2,n1) = (Z_std_real_ver(1,t,n2,n1)^2)/Z_mean_real_ver(1,t,n2,n1);
   Z_mean_pe_ver(1,t,n2,n1) = mean(Z_rate_pe_popu(1,t,situation,n1));
   Z_std_pe_ver(1,t,n2,n1) = std(Z_rate_pe_popu(1,t,situation,n1));
   FanoZ_pe_ver(1,t,n2,n1) = (Z_std_pe_ver(1,t,n2,n1)^2)/Z_mean_pe_ver(1,t,n2,n1);
  end
 end
end

for l_style = 1:size(stimulus,2)
  figure;
  aa = [];
  X = 1:(2*T1);
  for n2 = 1:size(VIP_neural_stregth,2) % n2 is responding strength
      clear Fano0;
      Fano0 = [FanoZ_pe_ver(1,:,n2,l_style),FanoZ_real_ver(1,:,n2,l_style)];
      plot(X,Fano0,'Color',[0.3,0.3,0.3]*n2);hold on;
      aa = [aa;'location ',num2str(n2)];
  end
  legend(aa);
end

% contribution of neurons in identification
clear Z_cluster;
for m = 1:size(Z_count_sti,4)
    clear cluster0
    cluster0 = net.action{1,m};
    Z_cluster(:,:,m) = cluster0;
end

Z_distance = zeros(size(Z_count_sti,1)*2,size(Z_count_sti,4));
Z_contri = Z_distance;
clear Z_spike_overtime;
Z_spike_overtime = sum(Z_count_sti,2);
clear Z_spiking;clear Z_spiking_overtime;
Z_spiking = zeros(size(Z_count_sti));
for n1 = 1:size(Z_count_sti,4) % for each situation
    for l = 1:size(Z_count_sti,3) % for each simulation
        for t = 1:size(Z_count_sti,2)
            t1 = max(t-1,1);
            Z_spiking(:,t1,l,n1) = (Z_spiking(:,t1,l,n1) + Z_count_sti(:,t,l,n1))*exp(-1/20);
        end
    end
end
Z_spiking_overtime = sum(Z_spiking,2);

% distance induced by neural group in inference to different situations
for m = 1:size(Z_count_sti,4)% for each situation
 for ll = 1:size(Z_count_sti,3)% for each simulation
     clear Z_distance0
     for t = 1:size(Z_cluster,2)   
         Z_distance0(:,t) = [Z_spike_overtime(:,1,ll,m);Z_spiking_overtime(:,1,ll,m)] - Z_cluster(:,t,m);
     end
     Z_distance(:,m) = Z_distance(:,m) + sum((Z_distance0.^2),2);
 end
end

% with the Maximum of distance, neural contributions in inference are
% measured
Z_contri = zeros(size(Z_distance));
clear max_distance;clear min_distance;
for m = 1:size(Z_distance,2)
    max_distance(m) = max(Z_distance(:,m));
    min_distance(m) = min(Z_distance(:,m));
    Z_contri(:,m) = 1 - (Z_distance(:,m)-min_distance(m))/(max_distance(m)-min_distance(m));
end

% plot neural contributions in inference at different strengths
clear contr_mu;clear contr_std;% average and standard variance of contributions in situations
for n1 = 1:size(stimulus,2)% for each situation
    Z_contri_strength = cell(2,1);
    for n2 = 1:size(VIP_neural_stregth,2) % for each strength
      clear situation;
      situation = VIP_neural_stregth{n1,n2};
      Z_contri_strength{n2,1} = Z_contri(situation,n1);
      contr_mu(n1,n2) = mean(Z_contri(situation,n1));contr_std(n1,n2) = std(Z_contri(situation,n1));
    end
    clear h;clear p;
    [h,p,ci,stats] = ttest2(Z_contri_strength{1,1}(:),Z_contri_strength{2,1}(:));
    % [h,p]
end

% neural contributions in two situations
% average and standard variance of contributions in situations

figure;
hindles = barweb(contr_mu,contr_std,1);
title('Neural contributions in identifications with strenths');



% PCA of ex. neural responses at different VIP neural firing
PCA_tem_responding_real0 = [];
PCA_tem_responding_pe0 = [];
for n1 = 1:size(Z_rate_real,4) % for each situation
    for n2 = 1:size(VIP_neural_stregth,2) % n2 is VIP responding strength
        clear situation;
        situation = VIP_neural_stregth{n1,n2};
        for nn2 = 1:length(situation)
         for t = 1:size(Z_rate_real,2) % for each time step
           PCA_tem_responding_real0(:,t,n1,n2,nn2) = (Z_rate_real(:,t,situation(nn2),n1)' * COEFF(:,1:2))';
           PCA_tem_responding_pe0(:,t,n1,n2,nn2) = ((Z_rate_pe(:,t,situation(nn2),n1)') * COEFF(:,1:2))';
         end
        end
    end
end
PCA_tem_pe = mean(PCA_tem_responding_pe0,5);
PCA_tem_real = mean(PCA_tem_responding_real0,5);
clear PCA_tem_responding;
for n1 = 1:size(Z_rate_real,4) % for each situation
    for n2 = 1:size(VIP_neural_stregth,2) % n2 is VIP responding strength
        PCA_tem_responding(:,:,n1,n2) = PCA_tem_real(:,:,n1,n2);
    end
end

d0 = 0.495/(size(PCA_tem_responding,2))*[1 1 1];
for n1 = 1:size(Z_rate_real,4) % for each situation
    figure;
    for n22 = 1:size(VIP_neural_stregth,2) % n2 is VIP responding strength
     for t = 1:size(PCA_tem_responding,2)-1
         x1 = PCA_tem_responding(1,t,n1,n22);x2 = PCA_tem_responding(1,t+1,n1,n22);
         x = [x1 x2];
         y1 = PCA_tem_responding(2,t,n1,n22);y2 = PCA_tem_responding(2,t+1,n1,n22);
         y = [y1 y2];
         facecolor = [0.5,0.5,0.5]*(n22-1)+d0*t; % the stimulus-presented duration
         plot(x1, y1,'o','Markersize',10,'Color',facecolor,'MarkerFaceColor',facecolor);hold on;
         plot(x, y,'-','LineWidth',5,'Color',facecolor);hold on;
     end
    end
    grid on;
    xlabel('PC1');ylabel('PC2');
end

% for different value of VIP inhi. neural firing
% network performance
for m1 = 1:size(stimulus,2) % for each situation
  
  iden_time_strength_ttest = cell(2,1);
  figure;
  for n2 = 1:size(VIP_neural_stregth,2) % n2 is responding strength
  clear situation;
  situation = VIP_neural_stregth{n1,n2};
  clear iden_time;
  iden_time = net.iden_t(m1,situation(:)');
  iden_time_strength_ttest{n2,1} = iden_time(:);
  color = [0.3 0.3 0.3]*n2;
  plot(n2,mean(iden_time),'o','Color',color,'markerfacecolor',color,'MarkerSize',15);hold on;
  errorbar(n2,mean(iden_time),std(iden_time),'Color',[.7,.7,.7]);hold on;
  end
  set(gca,'xLim',[0 3],'xTick',[1,2],'xTickLabel',{'1','2'});
  title('Performance with different strength of VIP inhi. neural firing')
  clear h;clear p;
  [h,p,ci,stats] = ttest2(iden_time_strength_ttest{1,1}(:),iden_time_strength_ttest{2,1}(:));
  [h,p]
end



end