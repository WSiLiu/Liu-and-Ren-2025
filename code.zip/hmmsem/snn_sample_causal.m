function [net,Z,P] = snn_sample_causal( net, data, ct )
net.update_on_spike =1;
t = data.time(ct(1));
time_range = (data.time(ct(end))-data.time(ct(1)));% time_range is the time duration
num_spikes = max(floor(time_range*1000),size(net.patterns{1,1},2));
spike_times = (1:num_spikes)/1000;
net.w_rf = -5;
net.tau_rf = 0.01;
net.num_neurons = net.num_bio_neurons;
count = [0;0];
count1 = [0;0];
iden_t = (-1)*ones(length(net.stimulus),1);
net.cue(1,:)

%% initial value of necessary variables
    Z_spikes = inf(net.num_bio_neurons,num_spikes); 
    a_Z = zeros(net.num_bio_neurons,1);
    Zleft_spikes = inf(net.num_ex_left,num_spikes);
    Zright_spikes = inf(net.num_ex_right,num_spikes);
    l_spikes = zeros(net.num_inneurons,num_spikes);

    Z = zeros(net.num_bio_neurons, num_spikes, 'single');
    Zleft =zeros(net.num_ex_left, num_spikes, 'single');
    Zright =zeros(net.num_ex_right, num_spikes, 'single');

    last_spikes_X = repmat(t, net.num_inputs, 1);
    last_spikes_Z = repmat(t, net.num_bio_neurons, 1);
    last_spikes_Zleft =repmat(t, net.num_ex_left, 1);
    last_spikes_Zright = repmat(t, net.num_ex_right, 1);
    last_spikes_l = repmat(t, net.num_inneurons, 1);


    aZleft = 0;
    aZright = 0;
    aZ = 0;
    
    
    last_spikes_X = repmat(t, net.num_inputs, 1);
    last_spikes_Z = repmat(t, net.num_bio_neurons, 1);
    
    hX = zeros(net.num_inputs, 2);
    hZleft = zeros(net.num_ex_left, 2);
    hZright = zeros(net.num_ex_right, 2);
    hZ = zeros(net.num_bio_neurons, 2);
    hl = zeros(net.num_inneurons, 2);
    
    net.d_Wleft = zeros(net.num_ex_left,net.num_inputs/2); % initial modifications of 1st feedforward weights
    net.d_Wright = zeros(net.num_ex_right,net.num_inputs/2); % initial modifications of 2nd feedforward weights
    net.d_VLtoR = zeros(net.num_ex_right,net.num_ex_left); % initial modifications of lateral connection from 1st to 2nd ex. neurons
    net.d_VRtoL = zeros(net.num_ex_left,net.num_ex_right); % initial modifications of lateral connection from 2nd to 1st ex. neurons
    net.d_VLtoB = zeros(net.num_bio_neurons,net.num_ex_left); % initial modifications of lateral connection from 1st to 3rd ex. neurons
    net.d_VBtoL = zeros(net.num_ex_left,net.num_bio_neurons); % initial modifications of lateral connection from 3rd to 1st ex. neurons
    net.d_VRtoB = zeros(net.num_bio_neurons,net.num_ex_right); % initial modifications of lateral connection from 2nd to 3rd ex. neurons
    net.d_VBtoR = zeros(net.num_ex_right,net.num_bio_neurons); % initial modifications of lateral connection from 3rd to 2nd ex. neurons
    net.d_VLtoL = zeros(net.num_ex_left,net.num_ex_left); % initial modifications of lateral connection from 1st to 1st ex. neurons
    net.d_VRtoR = zeros(net.num_ex_right,net.num_ex_right); % initial modifications of lateral connection from 2nd to 2nd ex. neurons
    net.d_VBtoB = zeros(net.num_bio_neurons,net.num_bio_neurons);  % initial modifications of lateral connection from 3rd to 3rd ex. neurons




    net.d_V =  zeros(net.num_bio_neurons,net.num_bio_neurons);




    
    P = zeros(net.num_bio_neurons, 1, 'single');
    net.At = zeros(2,num_spikes, 'single');
    A_v = zeros(1,num_spikes);
    A_w = zeros(1,num_spikes);
    %%
    i = 1;
    i_Zleft = 1;
    i_Zright = 1;
    i_Z = 1;
    i_l = 1;
    %%
    action = 0;
    reward = 0;

     if ~isfield( net, 'groups' )
         net.groups = 0;
     end
     if ~isfield( net, 'alpha_w' )
         net.alpha_w = 1;
     end
    if ~isfield( net, 'alpha_v' )
        net.alpha_v = 1;
    end
    if ~isfield( net, 'w_temperature' )
        net.w_temperature = 1;
    end
    
    group_idx = [ 0, cumsum( net.groups ), net.num_bio_neurons ]; 
    net.num_o(:) = 0;
    %%
    try
       for j = 1:num_spikes % num_spikes is the number of all the time steps
           j0 = floor(j/(net.T));% j0 is the number of previous stimuli
           j1 = j-(j0*net.T);% j1 is the time step of the current stimulus
           t = spike_times(j);

           % synaptic currents, membrane potentials and spiking rates have
           % to be updated at each time step

           % update feedforward synapses
           % synaptic currents in exponential forms are updated with time
            while (i < size(data.Xt,2)) && (t > data.Xt(2,i)) % i is the time step
                 n_id = data.Xt(1,i);
                 spiking_t = data.Xt(2,i);
                 hX(n_id,1) = hX(n_id,1)*exp(-double(spiking_t-last_spikes_X(n_id))/net.tau_x_r) + 1;
                 hX(n_id,2) = hX(n_id,2)*exp(-double(spiking_t-last_spikes_X(n_id))/net.tau_x_f) + 1;
                 last_spikes_X(n_id) = spiking_t;
                 i = i+1;
            end
            hX(:,1) = hX(:,1).*exp(-double(t-last_spikes_X)/net.tau_x_r);
            hX(:,2) = hX(:,2).*exp(-double(t-last_spikes_X)/net.tau_x_f);
            d_hX = diff(hX,1,2);
            hX_all(:,j) = d_hX;


            %%
             % update lateral synapses of 1st ex. neural group
             while (i_Zleft < size(Zleft_spikes,2)) && (t > i_Zleft/1000 )% i_Zleft is the time step
                 spiking_t = i_Zleft/1000;
                 for n_id = 1:net.num_ex_left
                     if Zleft_spikes(n_id,i_Zleft) == 1
                        hZleft(n_id,1) = hZleft(n_id,1)*exp(-double(spiking_t-last_spikes_Zleft(n_id))/net.tau_z_r) + 1;
                        hZleft(n_id,2) = hZleft(n_id,2)*exp(-double(spiking_t-last_spikes_Zleft(n_id))/net.tau_z_f) + 1;
                        last_spikes_Zleft(n_id) = spiking_t;
                     end
                 end
                 i_Zleft = i_Zleft+1;
             end
             hZleft(:,1) = hZleft(:,1).*exp(-double(t-last_spikes_Zleft)/net.tau_z_r);
             hZleft(:,2) = hZleft(:,2).*exp(-double(t-last_spikes_Zleft)/net.tau_z_f);
             d_hZleft = diff( hZleft,1,2 );
             hZleft_all(:,j) = d_hZleft;

             % update lateral synapses of 2nd ex. neural group
             while (i_Zright < size(Zright_spikes,2)) && (t > i_Zright/1000 )%i_Zright is the time step
                 spiking_t = i_Zright/1000;
                 for n_id = 1:net.num_ex_right
                     if Zright_spikes(n_id,i_Zright) == 1
                        hZright(n_id,1) = hZright(n_id,1)*exp(-double(spiking_t-last_spikes_Zright(n_id))/net.tau_z_r) + 1;
                        hZright(n_id,2) = hZright(n_id,2)*exp(-double(spiking_t-last_spikes_Zright(n_id))/net.tau_z_f) + 1;
                        last_spikes_Zright(n_id) = spiking_t;
                     end
                 end
                 i_Zright = i_Zright+1;
             end
             hZright(:,1) = hZright(:,1).*exp(-double(t-last_spikes_Zright)/net.tau_z_r);
             hZright(:,2) = hZright(:,2).*exp(-double(t-last_spikes_Zright)/net.tau_z_f);
             d_hZright = diff( hZright,1,2 );
             hZright_all(:,j) = d_hZright;

             % update lateral synapses of 3rd ex. neural group
             while (i_Z < size(Z_spikes,2)) && (t > i_Z/1000 ) %i_Z is the time step
                 spiking_t = i_Z/1000;
                 for n_id = 1:net.num_bio_neurons
                     if Z_spikes(n_id,i_Z) == 1
                        hZ(n_id,1) = hZ(n_id,1)*exp(-double(spiking_t-last_spikes_Z(n_id))/net.tau_z_r) + 1;
                        hZ(n_id,2) = hZ(n_id,2)*exp(-double(spiking_t-last_spikes_Z(n_id))/net.tau_z_f) + 1;
                        last_spikes_Z(n_id) = spiking_t;
                     end
                 end
                 i_Z = i_Z+1;
             end
             hZ(:,1) = hZ(:,1).*exp(-double(t-last_spikes_Z)/net.tau_z_r);
             hZ(:,2) = hZ(:,2).*exp(-double(t-last_spikes_Z)/net.tau_z_f);
             d_hZ = diff( hZ,1,2 );
             hZ_all(:,j) = d_hZ;

             % update lateral synapses of inhi. neural group
             while (i_l<size(l_spikes,2)) && (t > i_l/1000) %i_l is the time step
                 spiking_t = i_l/1000;
                 for n_id = 1:net.num_inneurons
                     if l_spikes(n_id,i_l) == 1
                        hl(n_id,1) = hl(n_id,1)*exp(-double(spiking_t -last_spikes_l(n_id))/net.tau_z_r) + 1;
                        hl(n_id,2) = hl(n_id,2)*exp(-double(spiking_t -last_spikes_l(n_id))/net.tau_z_f) + 1;
                        last_spikes_l(n_id) = spiking_t;
                     end
                 end
                 i_l = i_l+1;
             end

             hl(:,1) = hl(:,1).*exp(-double(t-last_spikes_l)/net.tau_z_r);
             hl(:,2) = hl(:,2).*exp(-double(t-last_spikes_l)/net.tau_z_f);
             d_hl = diff( hl,1,2 );
             hl_all(:,j) = d_hl;
             %%


            if (j1 == 0)&&(j>net.T) % all the synaptic currents are reset to be 0 after absence of each stimulus
                hX = zeros(net.num_inputs,2);
                hZleft = zeros(net.num_ex_left, 2);   
                hZright = zeros(net.num_ex_right, 2);    
                hZ = zeros(net.num_bio_neurons,2);    
                hl = zeros(net.num_inneurons,2);    
                last_spikes_Z(:) = t;
            end
             
            %% plastic weights are limited in the range if necessary
             net.W = min(1,max(0.00001,net.W));
             net.Wleft = min(1,max(0.00001,net.Wleft)).*net.Wleft0;
             net.Wright = min(1,max(0.00001,net.Wright)).*net.Wright0;
             Wleft_eye = [eye(net.num_inputs/2), zeros(net.num_inputs/2,net.num_inputs/2)];
             Wright_eye = [zeros(net.num_inputs/2,net.num_inputs/2),eye(net.num_inputs/2)];
             net.VLtoR = min(1,max(0.00001,net.VLtoR)).*net.VLtoR0;
             net.VRtoL = min(1,max(0.00001,net.VRtoL)).*net.VRtoL0;
             net.VLtoB = min(1,max(0.00001,net.VLtoB)).*net.VLtoB0;
             net.VBtoL = min(1,max(0.00001,net.VBtoL)).*net.VBtoL0;
             net.VRtoB = min(1,max(0.00001,net.VRtoB)).*net.VRtoB0;
             net.VBtoR = min(1,max(0.00001,net.VBtoR)).*net.VBtoR0;
             net.VLtoL = min(1,max(0.00001,net.VLtoL)).*net.VLtoL0;
             net.VRtoR = min(1,max(0.00001,net.VRtoR)).*net.VRtoR0;
             net.VBtoB = min(1,max(0.00001,net.VBtoB)).*net.VBtoB0;

            %% update membrane potential and draw spikes
             % update 1st ex. neural membrane potential and draw spikes
             % inhi. inputs and ex. inputs

             UZleft_ei =  double(net.EI_L.*net.EI_L0)*d_hl; 
             UZleft_ee = net.w_temperature*net.Wleft*Wleft_eye*d_hX + net.VLtoL*d_hZleft + net.VRtoL*d_hZright + net.VBtoL*d_hZ;
             % temporal membrance potential and spiking probability of 1st
             % ex. neurons
             UZleft = UZleft_ee + UZleft_ei;
             PZleft_t = zeros(net.num_ex_left,1);
             [PZleft_t,AZleft_t] = wta_softmax2( UZleft );

             % influnce of refractory periods
             % no spikes are induced during refractory periods
             PZleft_t = PZleft_t.*double(sum(Zleft_spikes(:,max(j-net.ex_delay,j1):max(j-1,j1)),2) == 0);
             % draw spikes from softmax distributions
             [Zleft_j,Kleft] = wta_draw_k2(PZleft_t,Zleft,j);
             Zleft(:,j) =Zleft_j(:);Zleft_spikes(:,j) = Zleft_j(:);
             aZleft = max(aZleft,size(Kleft,1));
             if (~isempty(Kleft))
               clear n_k;
                 for n_k = 1:size(Kleft,1)
                     k1 = Kleft(n_k);
                     if Zleft_j(k1) == 1
                     last_spikes_Zleft(k1) = t;
                     end
                 end
             end

             % update 2nd ex. neural membrane potential and draw spikes
             % inhi. inputs and ex. inputs
             UZright_ei = double(net.EI_R.*net.EI_R0)*d_hl;
             UZright_ee = net.w_temperature*net.Wright*Wright_eye*d_hX + net.VRtoR*d_hZright + net.VLtoR*d_hZleft + net.VBtoR*d_hZ;
             % temporal membrance potential and spiking probability of 2nd
             % ex. neurons
             UZright = UZright_ee + UZright_ei;
             PZright = zeros(net.num_ex_right,1);
             [PZright_t,AZright_t] = wta_softmax2(UZright);

             % influnce of refractory periods
             % no spikes are induced during refractory periods
             PZright_t = PZright_t.*double(sum(Zright_spikes(:,max(j-net.ex_delay,j1):max(j-1,j1)),2) == 0);
             % draw spikes from softmax distributions
             [Zright_j,Kright] = wta_draw_k2(PZright_t,Zright,j);
             Zright(:,j) =Zright_j(:);Zright_spikes(:,j) = Zright_j(:);
             aZright = max(aZright,size(Kright,1));
             if (~isempty(Kright))
                 clear n_k;
                 for n_k = 1:size(Kright,1)
                    k1 = Kright(n_k);
                    if Zright_j(k1) == 1
                    last_spikes_Zright(k1) = t;
                    end
                 end
             end

             % update 3rd ex. neural membrane potential and draw spikes
             % inhi. inputs and ex. inputs
             UZ_ei = double(net.EI_B.*net.EI_B0)*d_hl;
             UZ_ee = net.VLtoB*d_hZleft + net.VRtoB*d_hZright + net.VRtoR*d_hZ;
             
             UZ = UZ_ee + UZ_ei;
             PZ = zeros(net.num_bio_neurons,1);
             [PZ_t,AZ_t] = wta_softmax2( UZ );

             % influnce of refractory periods
             % no spikes are induced during refractory periods
             PZ_t = PZ_t.*double(sum(Z(:,max(j-net.ex_delay,j1):max(j-1,j1)),2) == 0);
             % draw spikes from softmax distributions
             [Z_j,K] = wta_draw_k2(PZ_t,Z,j);
             Z(:,j) =Z_j(:);Z_spikes(:,j) = Z_j(:);
             aZ = max(aZ,size(K,1));
             if (~isempty(K))
                 for n_k = 1:size(K,1)
                     k1 = K(n_k);
                     if Z_j(k1) == 1
                     last_spikes_Z(k1) = t;
                     end
                 end
             end
             % update inhi. neural membrane potential and draw spikes
             Ul_ie = double(net.IE_B.*net.IE_B0)*d_hZ + double(net.IE_L.*net.IE_L0)*d_hZleft + double(net.IE_R.*net.IE_R0)*d_hZright;
             Ul_ii = double(net.II.*net.II0)*d_hl;
             Ul = Ul_ie + Ul_ii;
             % influnce of refractory periods
             % no spikes are induced during refractory periods
             Pl(:,j) = net.I_firingrate*Ul.*double(Ul>0).*double(sum(l_spikes(:,max(j1,j-net.inhi_delay):max(j1,j-1)),2) == 0);
             l_spikes(:,j) = double(random('Poisson',Pl(:,j))>0);


            %% Update clustering sets
             % j0 is the number of previous stimuli and j1 is the time step of the current stimulus
             j0 = floor(j/(net.T));j1 = j-(j0*net.T);
             % during noisy durations, no identifications or rewards are considered
             if (j1<net.t_start)&&(j>(j0*(net.T))) 
                   action = 0;reward = 0;
             end
             % on stimulus onset, both identifications and rewards are reset
             if j1 == (net.T)/2 
                 action = 0;reward = 0;ident0 = 0; % iden_t0 is reset to mark the time of the first correct identification
             end
             if ((j > net.T)&&(j > (j0*(net.T)))&&(j1 >= net.t_start))||(j == num_spikes) % with stimulus presented
                 observe_size = 1;
                 clear observe;
                 observe = [Zleft(:,j+1-observe_size:j);Zright(:,j+1-observe_size:j);Z(:,j+1-observe_size:j)];
                 observe = observe(:,find(sum(observe)>0));

               %% Update blank clustering sets
                 % Add induced neural responses into blank clustering sets
                 if (j1<(net.t_start))&&(j0 <= size(net.action,2) + 1)
                 for ii = 1:size(net.n_clu_merged,2)
                  for jj = 1:net.N_cue
                  if (sum(sum(net.n_clu_merged(jj,ii))) == 0)&&(~isempty(observe))
                      net.action{jj,ii} = [net.action{jj,ii},observe];
                      net.action{jj,ii} = net.action{jj,ii}(:,find(sum(net.action{jj,ii})>0));
                      if size(net.action{jj,ii},2)>net.cluster_size
                         net.action{jj,ii} = net.action{jj,ii}(:,end-net.cluster_size+1:end);
                      end
                  end
                 end
                 end
                 end
               %% likelihoods for identification
                 N_cue = net.N_cue;
                 if (~isempty(observe))&&(j1 >= net.T/2)&&(net.cue(1,ceil(j/(net.T)))>0)&&(j < num_spikes)
                    % With non-blank neural responses, and stimuli presented, identifications are made
                    if reward == 0 % rewards depend on identifications of cue
                     p = zeros(N_cue,2);
                     p = probability_equaldistribution_clustering1(observe,net.action,p,net.significance,net.Repeat,net.N_cue,net.N_state);
                     % determine whether types determined by the cue are same
                     for nn = 1:N_cue % For each cue, action indicates the identification of its state.
                         clear aa1;clear aa2;
                         aa1 = p(nn,:);
                         action(1,nn) =  find(aa1 == max(aa1),1);% action(1,nn) is the identification of the nn th cue
                     end
                     clear c;clear c0;reward0 = 1;
                     for nn = 1:N_cue % For each cue, if the action is equal to the value of the cue, it is the correct identification.
                         reward0 = reward0 * double(action(nn) == net.cue(nn,ceil(j/(net.T)))) * double(j1 < net.T);
                     end
                     reward = reward0;% If identifications of all the cues are correct within the presented duration, the network will receive a possitive reward.
                     
                     if (reward == 1)&&(net.cue(1,ceil(j/(net.T)))>0)
                         ident0 = max(1,j1-(net.T)/2); % iden_t0 is the time of the first correction identification
                         iden_t(ceil(j/(net.T))-1,1) = ident0;
                         % show of simulating process if necessary
                         [j,ceil(j/(net.T))-1,ident0]
                     end

                     % if (j1 == net.T)||(j == num_spikes)
                     %     if reward == 0
                     %        ident0 = -1;
                     %        iden_t(ceil(j/(net.T))-1) = -1;
                     %     end
                     % end
                    end
                    % for mm = 1:net.N_cue
                    % count1(mm,1) = count1(mm,1) + 1;
                    % count(mm,1) = count(mm,1) + reward;
                    % end
                     
                 end

            %% update the clustering set
              if (min(action(:)) ~= 0)&&(reward == 1)&&(net.cue(1,ceil(j/(net.T)))>0)&&(j < num_spikes)&&(net.learning == 1)
                         sample = observe;
                         for nn1 = 1:net.N_cue
                             net.action{nn1,action(nn1)} = [net.action{nn1,action(nn1)},sample];
                             net.action{nn1,action(nn1)} = net.action{nn1,action(nn1)}(:,find(sum(net.action{nn1,action(nn1)})>0));
                             if size(net.action{nn1,action(nn1)},2)>net.cluster_size
                                 net.action{nn1,action(nn1)} = net.action{nn1,action(nn1)}(:,end-net.cluster_size+1:end);          
                             end 
                         end                     
              end
            %% synaptic weight updates (STDP)
             % STDP is controlled by reward
             if  (reward == 1)&&(net.cue(1,ceil(j/(net.T)))>0)&&(j < num_spikes)&&(net.learning == 1)
              eta = net.eta;
              % net.W = min(1,max(0.00001,net.W));
              % 1st feedforward weights
              net.Wleft = min(1,max(0.00001,net.Wleft));
              for n_k = 1:size(Zleft,1)
                  clear W_d;
                  W_d = 1-1./net.Wleft(n_k,:) + 1./(exp(net.Wleft(n_k,:))-1);
                  clear d_W_k1;clear d_W_k2;clear d_W_k;
                  d_W_k1 = Zleft(n_k,(j+1-observe_size):j).*(net.delayparameter.^(j-((j+1-observe_size):j)));
                  d_W_k2 = net.w_temperature*(Wleft_eye*hX_all(:,(j+1-observe_size):j))'-ones(j-(j+1-observe_size)+1,1)*W_d;
                  d_W_k = (eta*d_W_k1*d_W_k2)./max(eta*ones(size(W_d)),W_d);
                  net.Wleft(n_k,:) = net.Wleft(n_k,:) + d_W_k;
                  net.Wleft(n_k,:) = min(1,max(0.00001,net.Wleft(k1,:)));
              end
              net.Wleft = min(1,max(0.00001,net.Wleft)).*net.Wleft0;
              % 2nd feedforward weights
              net.Wright = min(1,max(0.00001,net.Wright));
              for n_k = 1:size(Zright,1)
                  clear W_d;
                  W_d = 1-1./net.Wright(n_k,:) + 1./(exp(net.Wright(n_k,:))-1);
                  clear d_W_k1;clear d_W_k2;
                  d_W_k1 = Zright(n_k,(j+1-observe_size):j).*(net.delayparameter.^(j-((j+1-observe_size):j)));
                  d_W_k2 = net.w_temperature*(Wright_eye*hX_all(:,(j+1-observe_size):j))'-ones(j-(j+1-observe_size)+1,1)*W_d;
                  d_W_k = (eta*d_W_k1*d_W_k2)./max(eta*ones(size(W_d)),W_d);
                  net.Wright(n_k,:) = net.Wright(n_k,:) + d_W_k;
                  net.Wright(n_k,:) = min(1,max(0.00001,net.Wright(n_k,:)));
              end
              net.Wright = min(1,max(0.00001,net.Wright)).*net.Wright0;

              % From 1st to 1st latent weights
              net.VLtoL = min(1,max(0.00001,net.VLtoL)).*net.VLtoL0;
              for n_k = 1:size(Zleft,1)
                  clear Vlefteye_d;
                  Vlefteye_d = 1-1./net.VLtoL(n_k,:) + 1./(exp(net.VLtoL(n_k,:))-1);
                  clear d_Vlefteye_k1;clear d_Vlefteye_k2;
                  d_Vlefteye_k1 = Zleft(n_k,(j+1-observe_size):j).*(net.delayparameter.^(j-((j+1-observe_size):j)));
                  d_Vlefteye_k2 = (hZleft_all(:,(j+1-observe_size):j))'-ones(j-(j+1-observe_size)+1,1)*Vlefteye_d;
                  d_Vlefteye_k = (eta*d_Vlefteye_k1*d_Vlefteye_k2)./max(eta*ones(size(Vlefteye_d)),Vlefteye_d);
                  net.VLtoL(n_k,:) = net.VLtoL(n_k,:) + d_Vlefteye_k;
                  net.VLtoL(n_k,:) = min(1,max(0.00001,net.VLtoL(n_k,:)));
              end
              for nn = 1:net.num_ex_left
                 net.VLtoL(nn,nn) = 0;
              end
              net.VLtoL = min(1,max(0.00001,net.VLtoL)).*net.VLtoL0;

              % From 2nd to 2nd latent weights
              net.VRtoR = min(1,max(0.00001,net.VRtoR)).*net.VRtoR0;
              for n_k = 1:size(Zright,1)
                  clear Vrighteye_d;
                  Vrighteye_d = 1 - 1./net.VRtoR(n_k,:) + 1./(exp(net.VRtoR(n_k,:))-1);
                  clear d_Vrighteye_k1;clear d_Vrighteye_k2;
                  d_Vrighteye_k1 = Zright(n_k,(j+1-observe_size):j).*(net.delayparameter.^(j-((j+1-observe_size):j)));
                  d_Vrighteye_k2 = (hZright_all(:,(j+1-observe_size):j))'-ones(j-(j+1-observe_size)+1,1)*Vrighteye_d;
                  d_Vrighteye_k = (eta*d_Vrighteye_k1*d_Vrighteye_k2)./max(eta*ones(size(Vrighteye_d)),Vrighteye_d);
                  net.VRtoR(n_k,:) = net.VRtoR(n_k,:) + d_Vrighteye_k;
                  net.VRtoR(n_k,:) = min(1,max(0.00001,net.VRtoR(n_k,:)));
              
              end
              for nn = 1:net.num_ex_right
                 net.VRtoR(nn,nn) = 0;
              end
              net.VRtoR = min(1,max(0.00001,net.VRtoR)).*net.VRtoR0;

              % From 3rd to 3rd latent weights
              net.VBtoB = min(1,max(0.00001,net.VBtoB)).*net.VBtoB0;
              for n_k = 1:size(Z,1)
                  clear VBtoB_d;
                  VBtoB_d = 1-1./net.VBtoB(n_k,:) + 1./(exp(net.VBtoB(n_k,:))-1);
                  clear d_VBtoB_k1;clear d_VBtoB_k2;
                  d_VBtoB_k1 = Z(n_k,(j+1-observe_size):j).*(net.delayparameter.^(j-((j+1-observe_size):j)));
                  d_VBtoB_k2 = (hZ_all(:,(j+1-observe_size):j))'-ones(j-(j+1-observe_size)+1,1)*VBtoB_d;
                  d_VBtoB_k = (eta*d_VBtoB_k1*d_VBtoB_k2)./max(eta*ones(size(VBtoB_d)),VBtoB_d);
                  net.VBtoB(n_k,:) = net.VBtoB(n_k,:) + d_VBtoB_k;
                  net.VBtoB(n_k,:) = min(1,max(0.00001,net.VBtoB(n_k,:)));
              end
              for nn = 1:net.num_bio_neurons
                 net.VBtoB(nn,nn) = 0;
              end
              net.VBtoB = min(1,max(0.00001,net.VBtoB)).*net.VBtoB0;


              % From 1st to 2nd latent weights
              net.VLtoR = min(1,max(0.00001,net.VLtoR)).*net.VLtoR0;
              for n_k = 1:size(Zright,1)
                  clear VLtoR_d;
                  VLtoR_d = 1 - 1./net.VLtoR(n_k,:) + 1./(exp(net.VLtoR(n_k,:))-1);
                  clear d_VLtoR_k1;clear d_VLtoR_k2;
                  d_VLtoR_k1 = Zright(n_k,(j+1-observe_size):j).*(net.delayparameter.^(j-((j+1-observe_size):j)));
                  d_VLtoR_k2 = (hZleft_all(:,(j+1-observe_size):j))'- ones(j-(j+1-observe_size)+1,1)*VLtoR_d;
                  d_VLtoR_k = (eta*d_VLtoR_k1*d_VLtoR_k2)./max(eta*ones(size(VLtoR_d)),VLtoR_d);
                  net.VLtoR(n_k,:) = net.VLtoR(n_k,:) + d_VLtoR_k;
                  net.VLtoR(n_k,:) = min(1,max(0.00001,net.VLtoR(n_k,:)));
              end
              net.VLtoR = min(1,max(0.00001,net.VLtoR)).*net.VLtoR0;

              % From 2nd to 1st latent weights
              net.VRtoL = min(1,max(0.00001,net.VRtoL)).*net.VRtoL0;
              for n_k = 1:size(Zleft,1)
                  clear VRtoL_d;
                  VRtoL_d = 1-1./net.VRtoL(n_k,:) + 1./(exp(net.VRtoL(n_k,:))-1);
                  clear d_VRtoL_k1;clear d_VRtoL_k2;
                  d_VRtoL_k1 = Zleft(n_k,(j+1-observe_size):j).*(net.delayparameter.^(j-((j+1-observe_size):j)));
                  d_VRtoL_k2 = (hZright_all(:,(j+1-observe_size):j))'-ones(j-(j+1-observe_size)+1,1)*VRtoL_d;
                  d_VRtoL_k = (eta*d_VRtoL_k1*d_VRtoL_k2)./max(eta*ones(size(VRtoL_d)),VRtoL_d);
                  net.VRtoL(n_k,:) = net.VRtoL(n_k,:) + d_VRtoL_k;
                  net.VRtoL(n_k,:) = min(1,max(0.00001,net.VRtoL(n_k,:)));
              end
              net.VRtoL = min(1,max(0.00001,net.VRtoL)).*net.VRtoL0;

              % From 3rd to 1st latent weights
              net.VBtoL = min(1,max(0.00001,net.VBtoL)).*net.VBtoL0;
              for n_k = 1:size(Zleft,1)
                  clear VBtoL_d;
                  VBtoL_d = 1-1./net.VBtoL(n_k,:) + 1./(exp(net.VBtoL(n_k,:))-1);
                  clear d_VBtoL_k1;clear d_VBtoL_k2;
                  d_VBtoL_k1 = Zleft(n_k,(j+1-observe_size):j).*(net.delayparameter.^(j-((j+1-observe_size):j)));
                  d_VBtoL_k2 = (hZ_all(:,(j+1-observe_size):j))'-ones(j-(j+1-observe_size)+1,1)*VBtoL_d;
                  d_VBtoL_k = (eta*d_VBtoL_k1*d_VBtoL_k2)./max(eta*ones(size(VBtoL_d)),VBtoL_d);
                  net.VBtoL(n_k,:) = net.VBtoL(n_k,:) + d_VBtoL_k;
                  net.VBtoL(n_k,:) = min(1,max(0.00001,net.VBtoL(n_k,:)));
              end
              net.VBtoL = min(1,max(0.00001,net.VBtoL)).*net.VBtoL0;

              % From 3rd to 2nd latent weights
              net.VBtoR = min(1,max(0.00001,net.VBtoR)).*net.VBtoR0;
              for n_k = 1:size(Zright,1)
                  clear VBtoR_d;
                  VBtoR_d = 1-1./net.VBtoR(n_k,:) + 1./(exp(net.VBtoR(n_k,:))-1);
                  clear d_VBtoR_k1;clear d_VBtoR_k2;
                  d_VBtoR_k1 = Zright(n_k,(j+1-observe_size):j).*(net.delayparameter.^(j-((j+1-observe_size):j)));
                  d_VBtoR_k2 = (hZ_all(:,(j+1-observe_size):j))'-ones(j-(j+1-observe_size)+1,1)*VBtoR_d;
                  d_VBtoR_k = (eta*d_VBtoR_k1*d_VBtoR_k2)./max(eta*ones(size(VBtoR_d)),VBtoR_d);
                  net.VBtoR(n_k,:) = net.VBtoR(n_k,:) + d_VBtoR_k;
                  net.VBtoR(n_k,:) = min(1,max(0.00001,net.VBtoR(n_k,:)));
              end
              net.VBtoR = min(1,max(0.00001,net.VBtoR)).*net.VBtoR0;

              % From 1st to 3rd latent weights
              net.VLtoB = min(1,max(0.00001,net.VLtoB)).*net.VLtoB0;
              for n_k = 1:size(Z,1)
                  clear VLtoB_d;
                  VLtoB_d = 1-1./net.VLtoB(n_k,:) + 1./(exp(net.VLtoB(n_k,:))-1);
                  clear d_VLtoB_k1;clear d_VLtoB_k2;
                  d_VLtoB_k1 = Z(n_k,(j+1-observe_size):j).*(net.delayparameter.^(j-((j+1-observe_size):j)));
                  d_VLtoB_k2 = (hZ_all(:,(j+1-observe_size):j))' - ones(j-(j+1-observe_size)+1,1)*VLtoB_d;
                  d_VLtoB_k = (eta*d_VLtoB_k1*d_VLtoB_k2)./max(eta*ones(size(VLtoB_d)),VLtoB_d);
                  net.VLtoB(n_k,:) = net.VLtoB(n_k,:) + d_VLtoB_k;
                  net.VLtoB(n_k,:) = min(1,max(0.00001,net.VLtoB(n_k,:)));
              end
              net.VLtoB = min(1,max(0.00001,net.VLtoB)).*net.VLtoB0;

              % From 2nd to 3rd latent weights
              net.VRtoB = min(1,max(0.00001,net.VRtoB)).*net.VRtoB0;
              for n_k = 1:size(Z,1)
                  clear VRtoB_d;
                  VRtoB_d = 1-1./net.VRtoB(n_k,:) + 1./(exp(net.VRtoB(n_k,:))-1);
                  clear d_VRtoB_k1;clear d_VRtoB_k2;
                  d_VRtoB_k1 = Z(n_k,(j+1-observe_size):j).*(net.delayparameter.^(j-((j+1-observe_size):j)));
                  d_VRtoB_k2 = (hZ_all(:,(j+1-observe_size):j))' - ones(j-(j+1-observe_size)+1,1)*VRtoB_d;
                  d_VRtoB_k = (eta*d_VRtoB_k1*d_VRtoB_k2)./max(eta*ones(size(VRtoB_d)),VRtoB_d);
                  net.VRtoB(n_k,:) = net.VRtoB(n_k,:) + d_VRtoB_k;

              end
              net.VRtoB = min(1,max(0.00001,net.VRtoB)).*net.VRtoB0;
             end
             
             if (j1 <= 1)&&(j>net.T)

                 hX = zeros(net.num_inputs,2);   
                 hZ = zeros(net.num_bio_neurons,2);    
                 hZleft = zeros(net.num_ex_left, 2);   
                 hZright = zeros(net.num_ex_right, 2);    
                 hl = zeros(net.num_inneurons,2);   

                 d_hX = diff(hX,1,2);
                 d_hZleft = diff( hZleft,1,2);
                 d_hZright = diff( hZright,1,2);
                 d_hZ = diff( hZ,1,2);
                 d_hl = diff(hl,1,2);

                 last_spikes_Zleft(:) = t;
                 last_spikes_Zright(:) = t;
                 last_spikes_Z(:) = t;
                 last_spikes_l(:) = t;

             end
             
             end
       end
        
        
        
        
    catch
           fprintf('There has been an error, while sampling!\nExcluding run from training\n');
           file_name = sprintf('/tmp/error_data_%u_%04u.mat', net.iteration, round(9999*rand()) );
           the_error = lasterror();
           fprintf( '\n%s\n', the_error.message );
           fprintf( '  in %s on line %i\n\n', the_error.stack(1).name, the_error.stack(end).line );
           fprintf('saving workspace to: %s\n', file_name);
           save( file_name );
           
           net.R = -100000;
           fprintf('pausing 10 seconds...\n');
           pause(1);
           return;
    end
    
    
    net.Z_spikes = Z_spikes(:,i_Z:end);
    net.R = mean( net.At(1,:) );
    net.A_v = A_v;
    net.A_w = A_w;
    
    net.hX = hX;
    net.hZ = hZ;
    
    net.spike_train = Z;
    size(Z)
    net.spike_train_left = Zleft;
    net.spike_train_right = Zright;
    count = count(1:net.N_cue,1);
    count1 = count1(1:net.N_cue,1);
    net.count = [net.count,count];
    net.total_count = [net.total_count,count1];
    % size(net.iden_t)
    % size(iden_t)
    net.iden_t = [net.iden_t,iden_t];% iden_t is the reaciton time and recorded
    % net.iden_t = net.iden_t(net.iden_t>0);
    
%%
end