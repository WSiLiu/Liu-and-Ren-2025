function neural_assemble0(test_data,net,stimulus,j,L,T0)

%% reaction time
clear RT_mu;clear RT_std;figure;% calculate averaged value and standard deviation of RT for each situation
for m1 = 1:size(stimulus,2)
  clear iden_time
  iden_time = net.iden_t(m1,:);
  plot(m1,iden_time,'o','color',[0.8,0.8,0.8]);hold on;
  RT_mu(m1,1) = mean(iden_time);
  RT_std(m1,1) = std(iden_time);
end
errorbar(RT_mu,RT_std,'*','color',[0.1,0.1,0.1],'LineWidth',1);xlim([0 (size(stimulus,2)+1)]);ylim([-5 50]);
set (gca,'xtick',1:1:size(stimulus,2));

top1 = max(net.iden_t(:));top2 = 0;xrange2 = 0;figure;
fre = [];bins = 1:1:top1;
name1 = [];
for m1 = 1:size(stimulus,2)% frequency histogram of RT for each situation
    clear iden_time;
    iden_time = net.iden_t(m1,3:end);
    [fre(m1,:) ~] = hist(iden_time,bins);
    color = m1*[0.2 0.2 0.2];
    name2 = ['situation',num2str(m1)];
    name1 = [name1;name2];
    h1 = histogram(iden_time,bins,'Facecolor',color);hold on;
    top2 = max(top2,max(fre(m1,:))+10);
    xrange2 = max(xrange2,ceil(max(iden_time(:))+5));
end
ylim([0 top2]);legend(name1);xlim([0 xrange2]);


end