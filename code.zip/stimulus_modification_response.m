function stimulus_modification_response(rate)
N_situation = size(rate,4);
clear Z_responses;
for nn = 1:N_situation
    clear Z_responses0;
    Z_responses0 = rate(:,:,:,nn);
    Z_responses(:,nn) = mean(mean(Z_responses0,2),3);
end

clear MI;figure;
MI = (Z_responses(:,1) - Z_responses(:,2))./(Z_responses(:,1) + Z_responses(:,2));
[a0,b0] = hist(MI(:));
a1 = a0./sum(a0);
bar(b0,a1,'Facecolor',[0.5,0.5,0.5]);ylim([0,1.1*max(a1(:))]);
end