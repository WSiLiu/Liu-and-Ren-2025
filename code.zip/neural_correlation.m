function p = neural_correlation(T1,spikes1,spikes2)
N_situation = size(spikes1,4);
 clear p;
 for n_situation = 1:N_situation
    for t = 1:T1
        clear Z1;clear Z2;clear Cov_XY;clear std_X;clear std_Y;
        Z1 = spikes1(1,t,:,n_situation);
        Z2 = spikes2(1,t,:,n_situation);
        Cov_XY = cov(Z2(:),Z1(:));
        std_Y = std(Z2(:));
        std_X = std(Z1(:));
        p(t,n_situation) = Cov_XY(2,1)/(std_X*std_Y);
    end
 end
end