function stimulus_induced_variability(rate)
N_neuron = size(rate,1);N_situation = size(rate,4);
clear alpha;% neural responses are compared over different situations.
for nn = 1:N_neuron
    clear Z_responses0;
    Z_responses0 = [rate(nn,:,:,1);rate(nn,:,:,2)];% neural firing rates in each situation and each time step
    Z_responses_ave_oversimulation = mean(mean(Z_responses0,1),3);% ave. over simulation
    var1 = var(Z_responses_ave_oversimulation);% var. over time
    Z_responses_situationtime = Z_responses0(:); 
    var2 = var(Z_responses_situationtime);% var. over both simulation and time
    alpha(nn,1) = var1/var2;
end

[a0,b0] = hist(alpha(:));
a1 = a0./sum(a0);
figure;
bar(b0,a1,'Facecolor',[0.5,0.5,0.5]);ylim([0,1.1*max(a1(:))]);
end
