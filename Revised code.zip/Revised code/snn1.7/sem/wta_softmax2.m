function [P,A] = wta_softmax2( U )
% 
% [P,A] = wta_softmax2( U )
%
% Calculates the softmax function normalised
% over first dimension.
% Safe softmax function, avoids problems due to
% finite float precision.
%
% 02.06.2010
%
     
   U_max =  max(U(:),[],1);U_min =  min(U(:),[],1);
   %dU = U_max - U_min;%U1 = U_max - dU;
   U = U - repmat( U_max, size(U) );
   %U = U./dU;
   %(U_max>0)*3/4*repmat( U_max, size(U) );

   U_exp1 = exp( U );
    
   U_exp2 = ones(size(U));
   
   A_n = U_exp1 + U_exp2;
   
   P = U_exp1./A_n;
   
   %P = U_exp./repmat( A_n, [size(U,1), ones(1,ndims(U)-1)] );
   
   if nargout>1
       A = log( A_n ) + U_max;
   end   
end
