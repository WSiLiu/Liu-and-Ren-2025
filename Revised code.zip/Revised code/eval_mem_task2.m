function eval_mem_task2( ex_path1,num_trials,state,T,stimulus,N_cue,N_spacial,define,concept,run_id,varargin )
% run_stoch_pattern_test( src_path )
%
% test stochastic replay of patterns
%
% David Kappel
% 24.01.2012
% 

%% create data sets

    [ num_trials, ...
      dt, ...
      sigm, ...
      test_data_generator, ...
      free_data_generator, ...
      eval_second_half_only, ...
      r_min ] = snn_process_options( varargin, ...
                                        'num_trials', num_trials, ...
                                        'dt', 0.001, ...
                                        'sigma', 0.01, ...
                                        'test_data_generator', [], ...
                                        'free_data_generator', [], ...
                                        'eval_second_half_only', false, ...
                                        'r_min', [] );

    dt = 0.001; sigm = 0.01;r_min = [];eval_second_half_only = 0;
    save_file = [ ex_path1,'mem_task_test2', num2str(num_trials),'.mat'];
    
    if nargin < 10
        src_file_name = locate_data_file( ex_path1, 'last' );
    else
        src_file_name = locate_data_file( ex_path1, run_id );
    end
    
    data = load( src_file_name );
    V0_save = data.net.V0;
    if ~isempty(test_data_generator)
        data_generator = test_data_generator;
    elseif isfield( data, 'train_set_generator' )
        data_generator = data.train_set_generator;
    else
        error( 'Data field ''train_set_generator'' required!' );
    end

    num_seqs = length( data_generator.pat_sequences );

    test_data = cell(num_seqs,num_trials);
    free_data = cell(num_seqs,2);

    old_verbose_option = snn_options( 'verbose', false );

    net = snn_set( data.net );
    net.V0 = V0_save;
    net.state = snn_set( data.net );
    net.count = zeros(N_cue,1);
    net.concept = concept;
    net.Ve_location = [];
    count = zeros(N_cue,1);
    net.total_count = zeros(N_cue,1);
    total_count = zeros(N_cue,1);
    st = data.sim_test{1}.time(1);
    samples = st:dt:data.sim_test{1}.time(end);
    
    fil = inline('exp( -((x-mu).^2)./(2*sigma^2) )', 'x', 'mu', 'sigma');
    
    pat_labels = { data_generator.pat_labels{:}, '' };
    
%% simulate test set
    peth_test = cell(num_seqs,1);
    test_data_generator = data_generator;
    test_data_generator.time_padding = 0.020;
    test_data_generator.seq_id = num_seqs;
    [patterns,pat_sequences,~,~,~,concept,Ve_location] = generate_patterns_test2(stimulus,T/2,N_spacial,define);
    test_data_generator.patterns = patterns;
    net.patterns = patterns;
    net.concept = concept;
    net.N_cue = N_cue;
    net.iden_t = [];
    net.learning = 0; % net is in testing simulations

    [tmp,net] = snn_simulate( net, [], 'set_generator', test_data_generator );
    net.total_count = zeros(N_cue,1);
    net.count = zeros(N_cue,1);
    test_data_generator.total_count = zeros(N_cue,1);
    test_data_generator.count = zeros(N_cue,1);
    count = zeros(N_cue,1);
    total_count = zeros(N_cue,1);
    
    for seq_id = 1:num_seqs
        pat_labels{seq_id} = num2str(seq_id);
        test_data_generator.seq_id = seq_id;
        cur_peth = zeros( 1, length(samples) );
        for trial = 1:num_trials
            fprintf('\n');
            fprintf('\n%c%c%c%c%3d%%',8,8,8,8,round(100*trial/num_trials))
            fprintf('\n');
            [patterns,pat_sequences,~,~,~,concept,Ve_location] = generate_patterns_test2(stimulus,T/2,N_spacial,define);
            net.concept = concept;
            concept
            net.Ve_location = [net.Ve_location,Ve_location(:)];
            net.total_count = zeros(N_cue,1);
            net.count = zeros(N_cue,1);
            test_data_generator.total_count = zeros(N_cue,1);
            test_data_generator.count = zeros(N_cue,1);
            test_data_generator.patterns = patterns;
            net.patterns = patterns;
            net.learning = 0; % net is in testing simulations
            
            [test_data{seq_id,trial},net] = snn_simulate( net, [], 'set_generator', test_data_generator );
            test_data{seq_id,trial}.Zt = net.ex_spike_train;% ex. neural spiking train
            test_data{seq_id,trial}.Lt = net.in_spike_train;% in. neural spiking train
            fprintf('\n');

        end
        
        fprintf('\n');
        peth_test{seq_id} = cur_peth;
    
        fprintf('\n%c%c%c%cdone.\n',8,8,8,8);       
        
    end
%% simulate free set

    samples_free = st:dt:data.sim_free{1}.time(end);
     
    peth_free = cell(num_seqs,1);
    
    if ~isempty(free_data_generator)
        data_generator = free_data_generator;
    elseif isfield( data, 'free_set_generator' )
        data_generator = data.free_set_generator;
    else
        for seq_id = 1:num_seqs
            seq = data_generator.pat_sequences{seq_id};
            seq = [ seq(1:ceil(length(seq)/2)), length(data_generator.patterns) ];
            data_generator.pat_sequences{seq_id} = seq;
        end
        
        pattern_length = data_generator.pattern_length;
        
        if ( numel( pattern_length ) == 1 )
            pattern_length = repmat( pattern_length, length( seq ), 1 );
        else
            pattern_length = pattern_length( 1:ceil(length(seq)/2) );
        end
        
        pattern_length(end-1) = 2*pattern_length(end-1);
        pattern_length(end) = (length(seq)-2)*pattern_length(end);
        
        data_generator.pattern_length = pattern_length;
    end
    
    num_spikes_free = zeros(net.num_bio_neurons,1);
    
    
    
     for seq_id = 1:num_seqs
        pat_labels{seq_id} = num2str(seq_id);

        data_generator.seq_id = seq_id;
        
        cur_peth = zeros( 1, length(samples_free) );
       
         for trial = 1:2

            fprintf('\n%c%c%c%c%3d%%\n',8,8,8,8,round(100*trial/2))
            [patterns,~,~,~,~,concept,Ve_location] = generate_patterns_test2(stimulus,T/2,N_spacial,define);
            concept
            net.concept = concept;
            net.learning = 0; % net is in testing simulations
            data_generator.patterns = patterns;
            free_data{seq_id,trial} = snn_simulate( net, [], 'set_generator', data_generator );
            av_time = zeros(1,net.num_bio_neurons);
            free_data{seq_id,trial}.av_time = av_time;
         end
        peth_free{seq_id} = cur_peth;
    
        fprintf('\n%c%c%c%cdone.\n',8,8,8,8);
        
     end
    
    snn_options( 'verbose', old_verbose_option );

    snn_options( 'verbose', old_verbose_option );

    
     save( save_file, 'net', 'test_data', 'peth_test', ...
                      'state', ...
                      'count', 'total_count','-v7.3');

end
