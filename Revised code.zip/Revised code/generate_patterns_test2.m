function [patterns,pat_sequences,free_pat_sequences,pat_labels,num_inputs,concept,Ve_location] = generate_patterns_test2(stimulus,T,N_spacial,define)

pat_sequences = cell(1,1);
patterns = cell(1,1);
pat_labels = cell(1,1);
pat_seq = [];
R0 = [];
concept = [];
Ve_location = [];
noisy_stren = 1;


load('visual_sti.mat');
name = 'visual_sti.mat';
name1 = ['time',num2str(1),num2str(1),num2str(1)];
rate1 = cell2mat(struct2cell(load(name,name1)));
N_neuron = size(rate1,1);



for n_stimulus = 1:length(stimulus)
    
    pat_seq0 = [];
    rate = [];
    
    jj = 1;
         if n_stimulus == 1 % for the first situation, the first stimulus is ori and the stimuli have same types
                cue_tem = 1;cue_spatial = 2;
                visualsti(N_spacial,define);
                clear rate_simulation;clear cue1;
                [rate_simulation,cue1] = generate_rate_simulation1(cue_tem,cue_spatial,noisy_stren,N_neuron,T);
                load('ve_location');
                Ve_location = [Ve_location,(ve_location+1)];
                pat_seq0(jj,1) = n_stimulus;
         elseif n_stimulus == 2% for the second situation, the first stimulus is brightness and the stimuli have same types
                cue_tem = 1;cue_spatial = 1;
                visualsti(N_spacial,define);
                clear rate_simulation;clear cue1;
                [rate_simulation,cue1] = generate_rate_simulation1(cue_tem,cue_spatial,noisy_stren,N_neuron,T);
                load('ve_location');
                Ve_location = [Ve_location,(ve_location+1)];
                pat_seq0(jj,1) = n_stimulus;% pat_seq0 = 1
         end
         pat_seq1 = max(pat_seq0(:));
         rate = [rate,rate_simulation];
         R0 = [R0,rate];
         pat_seq = [pat_seq,pat_seq1];
         concept = [concept,cue1];
         
         num_inputs = size(rate,1);
    
    
end
r_duration2 = zeros(N_neuron,2*T);
R0 = [r_duration2,R0];
pat_seq = [(-1)*ones(size(pat_seq,1),1),pat_seq];
concept = [(-1)*ones(size(concept,1),1),concept];
R0 = R0.*double(R0>0);

pat_sequences{1,1} = pat_seq;
patterns{1,1} = R0;
pat_labels{1,1} = num2str(1);
free_pat_sequences = pat_sequences;

name3 = 'patterns.mat';
name4 = 'pat_sequences.mat';
name5 = 'free_pat_sequences.mat';
name6 = 'pat_labels.mat';
name7 = 'num_inputs.mat';

save(name3,'patterns');
save(name4,'pat_sequences');
save(name5,'free_pat_sequences');
save(name6,'pat_labels');
save(name7,'num_inputs');
end