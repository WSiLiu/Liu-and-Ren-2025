function [save_path,patterns] = do_learning_task_concept( exp_path, pat_sequences, varargin )
% DO_LEARNING_TASK runs an experiment that uses the HMM SEM network
% 
% function save_path = do_learning_task( exp_path, pat_sequences, ... )
%
% Train patterns into a HMM SEM network. Returns path that contains the
% training results.
%
% 02.11.2011
% David Kappel
%

%% init

    [ num_bio_neurons, ...
      num_inputs, ...
      pattern_length, ...
      length_std, ...
      noise_length, ...
      input_rate, ...
      output_rate, ...
      num_train_sets, ...
      targets_per_pattern, ...
      num_patterns, ...
      num_samples, ...
      num_runs, ...
      num_train_samples, ...
      free_run_time, ...
      free_run_seqs, ...
      free_run_pat_lenghts, ...
      seq_probs, ...
      seq_ids, ...
      rec_delay, ...
      eta, ...
      save_interval, ...
      free_run_noise, ...
      iw_track_speed, ...
      w_rf, ...
      use_iw, ...
      reset_psps, ...
      use_variance_tracking, ...
      self_inhibition, ...
      tau_x_r, ...
      tau_z_r, ...
      tau_x_f, ...
      tau_z_f, ...
      tau_rf, ...
      train_method, ...
      sample_method, ...
      show_fig, ...
      pat_labels, ...
      pat_alpha, ...
      pat_beta, ...
      num_epochs, ...
      train_set_generator, ...
      performance_method, ...
      pattern_type, ...
      patterns, ...
      pretrain_ff_weights, ...
      field_collectors, ...
      net_V, ...
      input_process, ...
      regen_patterns, ...
      regen_seqs, ...
      groups, ...
      base_path, ...      
      changelog_flag, ...
      state, ...
      T, ...
      N_spacial, ...
      define, ...
      stimulus, ...
      concept, ...
      varargin ] = snn_process_options( varargin, ...
                                        'num_bio_neurons', [], ...
                                        'num_inputs', [], ...
                                        'pattern_length', [], ...
                                        'length_std', 0.000, ...
                                        'noise_length', 0, ...
                                        'input_rate', 100, ...
                                        'output_rate', 200, ...
                                        'num_train_sets', 1000, ...
                                        'targets_per_pattern', 10, ...
                                        'num_patterns', [], ...
                                        'num_samples', 10, ...
                                        'num_runs', 1, ...
                                        'num_train_samples', 3, ...
                                        'free_run_time', [], ...
                                        'free_run_seqs', [], ...
                                        'free_run_pat_lenghts', [], ...
                                        'seq_probs', [], ...
                                        'seq_ids', [], ...
                                        'rec_delay', 0.000, ...
                                        'eta', [], ...
                                        'save_interval', [], ...
                                        'free_run_noise', 0.00, ...
                                        'iw_track_speed', 0.001, ...
                                        'w_rf', 0, ...
                                        'use_iw', false, ...
                                        'reset_psps', false, ...
                                        'use_variance_tracking', false, ...
                                        'self_inhibition', 0, ...
                                        'tau_x_r', 0.002, ...
                                        'tau_z_r', 0.002, ...
                                        'tau_x_f', 0.02, ...
                                        'tau_z_f', 0.02, ...
                                        'tau_rf', 0.005, ...
                                        'train_method', 'rs', ...
                                        'sample_method', 'ctrfstere', ...
                                        'show_fig', false, ...
                                        'pat_labels', [], ...
                                        'pat_alpha', 0.2, ...
                                        'pat_beta', 0.8, ...
                                        'num_epochs', 1, ...
                                        'train_set_generator', [], ...                                        
                                        'performance_method', 'ct', ...
                                        'pattern_type', 'beta', ...
                                        'patterns', [], ...
                                        'pretrain_ff_weights', false, ...
                                        'collect', '[At,R]', ...
                                        'net_V', [], ...
                                        'input_process', 'poisson', ...
                                        'regen_patterns', false, ...
                                        'regen_seqs', false, ...
                                        'groups', [], ...
                                        'base_path', '', ...
                                        'changelog_flag', [], ...
                                        'state',[], ...
                                        'T', [], ...
                                        'N_spacial', [], ...
                                        'define', [], ...
                                        'stimulus', [], ...
                                        'concept', []);
    

    save_path = gen_results_path([base_path,exp_path], changelog_flag);
    if isempty( save_path )
        return;
    end
    data_set_files = dir( [ save_path, 'data_set_*.mat' ] );
    continue_training = 0;
    cur_iteration = 1;
    cur_epoch = 1;
    set_eta = true; % learning rate is set for the network
    num_patterns = length(stimulus);

 
    if isempty(eta)
        eta = 0.001;
        set_eta = false;
    end

    if ~isempty( data_set_files )

        continue_training = sscanf( data_set_files(end).name, 'data_set_%d.mat' );

        u_input = input( sprintf( 'continue training at iteration? (default %i): ', continue_training ), 's' );

        if ~isempty( str2num( u_input ) )
            continue_training = str2num( u_input );
            cur_iteration = mod( continue_training, 100000 )+1;
            cur_epoch = floor( continue_training/100000 )+1;
            
            if (cur_iteration <= 0)
                cur_iteration = 1;
            end
            if (cur_epoch <= 0)
                cur_epoch = 1;
            end
        end
    end

%% create data sets

    if isempty( num_patterns )
        if ~isempty( pat_sequences )
            num_patterns = max( [ pat_sequences{:} ] );
        elseif ~isempty( train_set_generator )
            num_patterns = length( train_set_generator.pat_labels );
        else
            error( 'invalid parameters: unknown number of patterns!' );
        end
    end

    if ~isempty( pat_sequences )  
        if ( continue_training == 0 )

            performance = nan( num_epochs, ceil(num_train_sets/save_interval) );
            num_trials = nan( num_epochs, num_train_sets );
            all_seq_ids = zeros( num_epochs, num_train_sets );

        else

            old_path = locate_data_file( save_path, continue_training );

            if isempty( old_path )
                error( 'File not found!' );
            end

            fprintf( 'restoring experiment state %s...\n', old_path );
            old_data = load( old_path, 'patterns', 'pat_sequences', 'net', ...
                             'train_set_generator', 'performance', 'num_trials', 'all_seq_ids' );

            net = old_data.net;
            performance = old_data.performance;
            
            if isfield( old_data, 'train_set_generator' )
                train_set_generator = old_data.train_set_generator;
            end

            if isfield( old_data, 'patterns' )
                patterns = old_data.patterns;
            end
            
            if isfield( old_data, 'pat_sequences' )
                pat_sequences = old_data.pat_sequences;
            end
        end

        if isempty( pat_labels )
            if isfield( train_set_generator, 'pat_labels' )                
                pat_labels = train_set_generator.pat_labels;
            else
                num_pats = max( [pat_sequences{:}] );
                pat_labels = mat2cell( char( 'A' + (1:num_pats) - 1 ), 1, ones(1,num_pats) );
            end
        end
        num_seqs = length(pat_sequences);

        if isempty( train_set_generator )
            train_set_generator = struct();
            train_set_generator.patterns = patterns;
            train_set_generator.pat_sequences = pat_sequences;
            train_set_generator.pattern_length = pattern_length;
            train_set_generator.targets_per_pattern = targets_per_pattern;
            train_set_generator.length_std = length_std;
            train_set_generator.fcn_generate = @( data_gen, i )( generate_pattern_sequence_n( data_gen, i ) );
            train_set_generator.process = input_process;
        end

        if ischar( pat_sequences ) && strcmp( pat_sequences, 'basic_set_generator' )
            if isempty( train_set_generator )
                error( 'Basic train set generator required!' )
            end

            train_set_generator.patterns = patterns;
            train_set_generator.pattern_length = pattern_length;
            train_set_generator.targets_per_pattern = targets_per_pattern;
            train_set_generator.length_std = length_std;
            train_set_generator.process = input_process;
        end
        
    elseif isempty( train_set_generator )
        error( 'Argument ''train_set_genrator'' or ''pat_sequences'' required!' );
    elseif isfield( train_set_generator, 'pat_sequences' )
        num_seqs = length(train_set_generator.pat_sequences);
    else
        num_seqs = num_train_samples;
    end
    
    if isempty( seq_probs )
        seq_probs = ones( num_seqs, 1 )./num_seqs;
    end

    if ~isfield( train_set_generator, 'pat_labels' )
        train_set_generator.pat_labels = pat_labels;
    end
    
    if ~isempty( free_run_pat_lenghts )
        free_run_pat_lenghts(end+1) = free_run_time - sum(free_run_pat_lenghts);
        free_set_generator.pattern_length = free_run_pat_lenghts;
    end


%% create network

    snn_options( 'verbose', true );

    for epoch = cur_epoch:num_epochs

        if ( continue_training == 0 )
            num_inneurons = ceil(num_bio_neurons/4);
            net = snn_new( num_bio_neurons, num_inputs, ...
                           'train_method', train_method, ...
                           'sample_method', sample_method, ...
                           'performance_method', performance_method, ...
                           'lambda', output_rate, ...
                           'self_inhibition', self_inhibition, ...
                           'iw_track_speed', iw_track_speed, ...
                           'tau_x_r', tau_x_r, ...
                           'tau_z_r', tau_z_r, ...
                           'tau_x_f', tau_x_f, ...
                           'tau_z_f', tau_z_f, ...
                           'tau_rf', tau_rf, ...
                           'w_rf', w_rf, ...
                           'mean_rec_delay', rec_delay, ...                       
                           'use_iw', use_iw, ...
                           'eta', eta, ...
                           'groups', groups, ...
                           'use_variance_tracking', use_variance_tracking, ...
                           'num_samples', num_samples, ...
                           'num_inneurons', num_inneurons, ...
                           varargin{:} );

            if ~isempty( patterns )
                train_set_generator.patterns = patterns;
            end

            % create training/testing sets
            if regen_seqs || (epoch == 1)
                fprintf( 'creating test sets...  0%%' );

                num_test_sets = 1;%min( num_seqs, 5 );
                test_set = cell(1,num_test_sets);
                

                for i = 1:num_test_sets

                    test_set{i}.seq_id = i;        
                    train_set_generator.seq_id = i;
                    [patterns,pat_sequences,~,~,~,concept,Ve_location] = generate_patterns1(stimulus,T/2,N_spacial,define);
                   
                    train_set_generator.patterns = patterns;
                    net.pat_sequences = pat_sequences;
                    net.concept = concept;
                    net.list = 1:length(stimulus);
                    test_set{i}.data = train_set_generator.fcn_generate( train_set_generator, 1 );
                    fprintf('%c%c%c%c%3d%%',8,8,8,8,round(100*i/num_seqs))
                    
                end

                fprintf('%c%c%c%cdone.\n',8,8,8,8);
                fprintf( 'creating free run sets...  0%%' );

                free_run_data = cell(1,num_test_sets);

                free_set_generator = train_set_generator;

                if ~isempty( free_run_seqs )
                    free_run_seqs;
                    for i=1:length(free_run_seqs)
                        free_run_seqs{i}(end) = length( free_set_generator.patterns );
                    end
                    free_set_generator.free_run_seqs = free_run_seqs;
                    free_set_generator.pat_sequences = free_run_seqs;
                    free_set_generator.process = input_process;
                end

                for i = 1:num_test_sets
                    free_run_data{i}.seq_id = i;
                    free_set_generator.seq_id = i;
                    [patterns,pat_sequences,~,~,~,concept,Ve_location] = generate_patterns1(stimulus,T/2,N_spacial,define);
                    free_set_generator.patterns = patterns;
                    free_set_generator.pat_sequences = pat_sequences;
                    net.pat_sequences = pat_sequences;
                    net.concept = concept;
                    
                    free_run_data{i}.data = free_set_generator.fcn_generate( free_set_generator, 1 );
                    fprintf('%c%c%c%c%3d%%',8,8,8,8,round(100*i/num_seqs))
                end

                fprintf('%c%c%c%cdone.\n',8,8,8,8);
            end
                       
            if pretrain_ff_weights
                pats = [ train_set_generator.patterns{1:num_patterns} ];
                net.W = repmat( log(pats/10), 1, ceil(num_bio_neurons/num_patterns) )';
                net.W = max( -50, net.W(1:num_bio_neurons,1:num_inputs) );
            end
            
            if ~isempty( net_V )
                net.V = net_V;
            end
        end

        continue_training = 0;
        net.num_runs = 1;

        %% Basic structure of the network
        
        net.num_inputs = num_inputs;
        net.adapt = double((rand(1,num_bio_neurons) > 0.8))'; % number of adapt neurons
        net.tao_a = 5;
        % There are three groups of ex. neurons
        net.num_bio_neurons = num_bio_neurons; % 3rd ex. neural group
        num_ex_left = num_bio_neurons; % 1st ex. neural group
        num_ex_right = num_ex_left; % 2nd ex. neural group
        
        net.num_ex_left = num_ex_left;
        net.num_ex_right = num_ex_right;

        num_inneurons = ceil(num_bio_neurons/4); % number of in. neurons
        net.num_inneurons = num_inneurons;

        % innitial synaptic currents
        net.hX_init = zeros( num_inputs, 2 );
        net.hZ_init = zeros( num_bio_neurons, 2 );
        net.hl_init = zeros( num_inneurons, 2 );

        net.reset_psps = reset_psps;
        net.ex_delay = 10; % refractory period of downstream ex. neurons
        net.inhi_delay = 3; % refractory period of downstream in. neurons
        net.RT = []; % reaction time is reset to measure performance of the network
        net.observe_size = 1; % neural responses in the current time step for identifications
        
        net.t_start = 1; % the time step to start identificaions
        net.N_concept = 1; % number of set of spatial concept
        net.N_state = 2; % number of possible states of each concept
        % net.iden_t = zeros(length(stimulus),1);
        net.iden_t = [];
        net.Ve_location = [];
        net.action = cell(net.N_concept,net.N_state); % clustering sets for possible value of hidden cue
        for nn = 1:net.N_state
            for jj = 1:net.N_concept
                net.action{jj,nn} = zeros(2*net.num_bio_neurons, 1);
            end
        end

        net.stimulus = stimulus;
        net.concept = concept;
        net.delayparameter = 0.1^(1/net.observe_size);% delay contanst of reward
        net.beta = 0.9;
        net.Repeat = 20;% repeating samples in identificaitons
        net.cluster_size = 20;% size of clustering sets
        net.p_action = 1;% probability to generate identificaions
        net.p_update = net.p_action;
        net.count = zeros(net.N_concept,1);
        net.total_count = zeros(net.N_concept,1);
        net.stability = zeros(net.N_state,1);% DVA of vectors in clustering sets during training phase
        
        net.T = T;
        net.I_firingrate =  1;
        net.eta = 0.001; % learning rate for the network
        net.n_clu_merged = zeros(net.N_concept,2);% N_cue is the number of hidden cues. Each cue has 2 states.
        net.learning = 1; % net is in learning simulations
        net.ex_weight_fix = 0.5;
        net.in_weight_fix = 0.5;

        % There are 8 types of Layer 2/3 neurons. 
        % L23 Pry,  PV L23 BC,  PV ChC,  SOM L23 MC,  SOM L23 BC,  SOM BTC,  VIP BTC,  VIP BPC
       %% Connective prob. and matrix
        net.W0 = double(unifrnd(0,1,num_bio_neurons,num_inputs)<0.5);
        net.W = double(unifrnd(0.001,1,num_bio_neurons,num_inputs)).*net.W0;
        % Connective prob. from L23 Pry to L23 Pry: 1.8%.
        net.V0 = double(unifrnd(0,1,num_bio_neurons,num_bio_neurons)<1.8/100);
        net.V = double(unifrnd(0.001,1,num_bio_neurons,num_bio_neurons).*net.V0);
        for nn = 1:num_bio_neurons
            net.V(nn,nn) = 0;
        end
        % Types of inhi. neurons are designed proportionally.
        Num_inhi = (80 + 2 + 66 + 24 + 10 + 22 + 18);
        num_inneurons1 = max(1, floor(80/Num_inhi * num_inneurons)); % num_inneurons1 for PV L23 BC
        num_inneurons2 = max(1, ceil(2/Num_inhi * num_inneurons)); % num_inneurons2 for PV L23 ChC
        num_inneurons3 = max(1, floor(66/Num_inhi * num_inneurons)); % num_inneurons3 for SOM L23 MC
        num_inneurons4 = max(1, floor(24/Num_inhi * num_inneurons)); % num_inneurons3 for SOM L23 BC
        num_inneurons5 = max(1, ceil(10/Num_inhi * num_inneurons)); % num_inneurons3 for SOM BTC
        num_inneurons6 = max(1, floor(22/Num_inhi * num_inneurons)); % num_inneurons3 for VIP BTC
        num_inneurons7 = max(1, (num_inneurons - num_inneurons1 - num_inneurons2 ...
                - num_inneurons3 - num_inneurons4 - num_inneurons5 - num_inneurons6)); % num_inneurons3 for VIP BPC
       % indication of PV inhi.neurons
       net.PV = [ones(1,num_inneurons1),ones(1,num_inneurons2),zeros(1,num_inneurons3),zeros(1,num_inneurons4),...
                zeros(1,num_inneurons5),zeros(1,num_inneurons6),zeros(1,num_inneurons7)];
       % indication of SOM inhi.neurons
       net.SOM = [zeros(1,num_inneurons1),zeros(1,num_inneurons2),ones(1,num_inneurons3),ones(1,num_inneurons4),...
                ones(1,num_inneurons5),zeros(1,num_inneurons6),zeros(1,num_inneurons7)];
       % indication of VIP inhi.neurons
       net.VIP = [zeros(1,num_inneurons1),zeros(1,num_inneurons2),zeros(1,num_inneurons3),zeros(1,num_inneurons4),...
                zeros(1,num_inneurons5),ones(1,num_inneurons6),ones(1,num_inneurons7)];
        
        
        
        % Matrix of inhi. has 7*7 sub-matrixes.
        % Connective  prob. from PV L23 BC to PV L23 BC: 41.2%.
        II11 = double(unifrnd(0,1,num_inneurons1,num_inneurons1)<41.2/100);
        II110 = double(II11~=0);
        % Connective  prob. from PV ChC to PV L23 BC: 0%.
        II12 = double(unifrnd(0,1,num_inneurons1,num_inneurons2)<0/100);
        II120 = double(II12~=0);
        % Connective  prob. from SOM L23 MC to PV L23 BC: 48.9%.
        II13 = double(unifrnd(0,1,num_inneurons1,num_inneurons3)<48.9/100);
        II130 = double(II13~=0);
        % Connective  prob. from SOM L23 BC to PV L23 BC: 46.8%.
        II14 = double(unifrnd(0,1,num_inneurons1,num_inneurons4)<46.8/100);
        II140 = double(II14~=0);
        % Connective  prob. from SOM BTC to PV L23 BC: 2.9%.
        II15 = double(unifrnd(0,1,num_inneurons1,num_inneurons5)<2.9/100);
        II150 = double(II15~=0);
        % Connective  prob. from VIP BTC to PV L23 BC: 2.9%.
        II16 = double(unifrnd(0,1,num_inneurons1,num_inneurons6)<2.9/100);
        II160 = double(II16~=0);
        % Connective  prob. from VIP BPC to PV L23 BC: 0%.
        II17 = double(unifrnd(0,1,num_inneurons1,num_inneurons7)<0/100);
        II170 = double(II17~=0);
        
        % Connective  prob. from PV L23 BC to PV ChC: 0%.
        II21 = double(unifrnd(0,1,num_inneurons2,num_inneurons1)<0/100);
        II210 = double(II21~=0);
        % Connective  prob. from PV ChC to PV ChC: 37.5%.
        II22 = double(unifrnd(0,1,num_inneurons2,num_inneurons2)<37.5/100);
        II220 = double(II22~=0);
        % Connective  prob. from SOM L23 MC to PV ChC: 45.5%.
        II23 = double(unifrnd(0,1,num_inneurons2,num_inneurons3)<45.5/100);
        II230 = double(II23~=0);
        % Connective  prob. from SOM L23 BC to PV ChC: 13.3%.
        II24 = double(unifrnd(0,1,num_inneurons2,num_inneurons4)<13.3/100);
        II240 = double(II24~=0);
        % Connective  prob. from SOM BTC to PV ChC: 0%.
        II25 = double(unifrnd(0,1,num_inneurons2,num_inneurons5)<0/100);
        II250 = double(II25~=0);
        % Connective  prob. from VIP BTC to PV ChC: 0%.
        II26 = double(unifrnd(0,1,num_inneurons2,num_inneurons6)<0/100);
        II260 = double(II26~=0);
        % Connective  prob. from VIP BPC to PV ChC: 0%.
        II27 = double(unifrnd(0,1,num_inneurons2,num_inneurons7)<0/100);
        II270 = double(II27~=0);
        
        % Connective  prob. from PV L23 BC to SOM L23 MC: 18.2%.
        II31 = double(unifrnd(0,1,num_inneurons3,num_inneurons1)<18.2/100);
        II310 = double(II31~=0);
        % Connective  prob. from PV ChC to SOM L23 MC: 0%.
        II32 = double(unifrnd(0,1,num_inneurons3,num_inneurons2)<0/100);
        II320 = double(II32~=0);
        % Connective  prob. from SOM L23 MC to SOM L23 MC: 0%.
        II33 = double(unifrnd(0,1,num_inneurons3,num_inneurons3)<0/100);
        II330 = double(II33~=0);
        % Connective  prob. from SOM L23 BC to SOM L23 MC: 11.1%.
        II34 = double(unifrnd(0,1,num_inneurons3,num_inneurons4)<11.1/100);
        II340 = double(II34~=0);
        % Connective  prob. from SOM BTC to SOM L23 MC: 40%.
        II35 = double(unifrnd(0,1,num_inneurons3,num_inneurons5)<40/100);
        II350 = double(II35~=0);
        % Connective  prob. from VIP BTC to SOM L23 MC: 26.1%.
        II36 = double(unifrnd(0,1,num_inneurons3,num_inneurons6)<26.1/100);
        II360 = double(II36~=0);
        % Connective  prob. from VIP BPC to SOM L23 MC: 0%.
        II37 = double(unifrnd(0,1,num_inneurons3,num_inneurons7)<0/100);
        II370 = double(II37~=0);
        
        % Connective  prob. from PV L23 BC to SOM L23 BC: 46.8%.
        II41 = double(unifrnd(0,1,num_inneurons4,num_inneurons1)<46.8/100);
        II410 = double(II41~=0);
        % Connective  prob. from PV ChC to SOM L23 BC: 0%.
        II42 = double(unifrnd(0,1,num_inneurons4,num_inneurons2)<0/100);
        II420 = double(II42~=0);
        % Connective  prob. from SOM L23 MC to SOM L23 BC: 33.3%.
        II43 = double(unifrnd(0,1,num_inneurons4,num_inneurons3)<33.3/100);
        II430 = double(II43~=0);
        % Connective  prob. from SOM L23 BC to SOM L23 BC: 25%.
        II44 = double(unifrnd(0,1,num_inneurons4,num_inneurons4)<25/100);
        II440 = double(II44~=0);
        % Connective  prob. from SOM BTC to SOM L23 BC: 0%.
        II45 = double(unifrnd(0,1,num_inneurons4,num_inneurons5)<0/100);
        II450 = double(II45~=0);
        % Connective  prob. from VIP BTC to SOM L23 BC: 2.9%.
        II46 = double(unifrnd(0,1,num_inneurons4,num_inneurons6)<2.9/100);
        II460 = double(II46~=0);
        % Connective  prob. from VIP BPC to SOM L23 BC: 0%.
        II47 = double(unifrnd(0,1,num_inneurons4,num_inneurons7)<0/100);
        II470 = double(II47~=0);
        
        % Connective  prob. from PV L23 BC to SOM BTC: 11.4%.
        II51 = double(unifrnd(0,1,num_inneurons5,num_inneurons1)<11.4/100);
        II510 = double(II51~=0);
        % Connective  prob. from PV ChC to SOM BTC: 0%.
        II52 = double(unifrnd(0,1,num_inneurons5,num_inneurons2)<0/100);
        II520 = double(II52~=0);
        % Connective  prob. from SOM L23 MC to SOM BTC: 40%.
        II53 = double(unifrnd(0,1,num_inneurons5,num_inneurons3)<40/100);
        II530 = double(II53~=0);
        % Connective  prob. from SOM L23 BC to SOM BTC: 0%.
        II54 = double(unifrnd(0,1,num_inneurons5,num_inneurons4)<0/100);
        II540 = double(II54~=0);
        % Connective  prob. from SOM BTC to SOM BTC: 0%.
        II55 = double(unifrnd(0,1,num_inneurons5,num_inneurons5)<0/100);
        II550 = double(II55~=0);
        % Connective  prob. from VIP BTC to SOM BTC: 14.4%.
        II56 = double(unifrnd(0,1,num_inneurons5,num_inneurons6)<14.4/100);
        II560 = double(II56~=0);
        % Connective  prob. from VIP BPC to SOM BTC: 0%.
        II57 = double(unifrnd(0,1,num_inneurons5,num_inneurons7)<0/100);
        II570 = double(II57~=0);
        
        % Connective prob. from PV L23 BC to VIP BTC: 11.4%.
        II61 = double(unifrnd(0,1,num_inneurons6,num_inneurons1)<11.4/100);
        II610 = double(II61~=0);
        % Connective  prob. from PV ChC to VIP BTC: 0%.
        II62 = double(unifrnd(0,1,num_inneurons6,num_inneurons2)<0/100);
        II620 = double(II62~=0);
        % Connective  prob. from SOM L23 MC to VIP BTC: 47.8%.
        II63 = double(unifrnd(0,1,num_inneurons6,num_inneurons3)<47.8/100);
        II630 = double(II63~=0);
        % Connective  prob. from SOM L23 BC to VIP BTC: 11.4%.
        II64 = double(unifrnd(0,1,num_inneurons6,num_inneurons4)<11.4/100);
        II640 = double(II64~=0);
        % Connective  prob. from SOM BTC to VIP BTC: 14.4%.
        II65 = double(unifrnd(0,1,num_inneurons6,num_inneurons5)<14.4/100);
        II650 = double(II65~=0);
        % Connective  prob. from VIP BTC to VIP BTC: 7.7%.
        II66 = double(unifrnd(0,1,num_inneurons6,num_inneurons6)<7.7/100);
        II660 = double(II66~=0);
        % Connective  prob. from VIP BPC to VIP BTC: 0%.
        II67 = double(unifrnd(0,1,num_inneurons6,num_inneurons7)<0/100);
        II670 = double(II67~=0);
        
        % Connective  prob. from PV L23 BC to VIP BPC: 4.3%.
        II71 = double(unifrnd(0,1,num_inneurons7,num_inneurons1)<4.3/100);
        II710 = double(II71~=0);
        % Connective  prob. from PV ChC to VIP BPC: 0%.
        II72 = double(unifrnd(0,1,num_inneurons7,num_inneurons2)<0/100);
        II720 = double(II72~=0);
        % Connective  prob. from SOM L23 MC to VIP BPC: 43.8%.
        II73 = double(unifrnd(0,1,num_inneurons7,num_inneurons3)<43.8/100);
        II730 = double(II73~=0);
        % Connective  prob. from SOM L23 BC to VIP BPC: 4.3%.
        II74 = double(unifrnd(0,1,num_inneurons7,num_inneurons4)<4.3/100);
        II740 = double(II74~=0);
        % Connective  prob. from SOM BTC to VIP BPC: 9.1%.
        II75 = double(unifrnd(0,1,num_inneurons7,num_inneurons5)<9.1/100);
        II750 = double(II75~=0);
        % Connective  prob. from VIP BTC to VIP BPC: 6.7%.
        II76 = double(unifrnd(0,1,num_inneurons7,num_inneurons6)<6.7/100);
        II760 = double(II76~=0);
        % Connective  prob. from VIP BPC to VIP BPC: 0%.
        II77 = double(unifrnd(0,1,num_inneurons7,num_inneurons7)<0/100);
        II770 = double(II77~=0);
        
        net.II = (-net.in_weight_fix)*double([[II11,II12,II13,II14,II15,II16,II17]; ...
            [II21,II22,II23,II24,II25,II26,II27]; ... 
            [II31,II32,II33,II34,II35,II36,II37]; ...
            [II41,II42,II43,II44,II45,II46,II47]; ...
            [II51,II52,II53,II54,II55,II56,II57]; ... 
            [II61,II62,II63,II64,II65,II66,II67]; ... 
            [II71,II72,II73,II74,II75,II76,II77] ]);
        net.II0 = double([[II110,II120,II130,II140,II150,II160,II170]; ...
            [II210,II220,II230,II240,II250,II260,II270]; ... 
            [II310,II320,II330,II340,II350,II360,II370]; ...
            [II410,II420,II430,II440,II450,II460,II470]; ...
            [II510,II520,II530,II540,II550,II560,II570]; ... 
            [II610,II620,II630,II640,II650,II660,II670]; ... 
            [II710,II720,II730,II740,II750,II760,II770] ]);
        
        % connection from VIP inhi. neurons to other inhi. neurons
        net.IVIP0 = double([[zeros(size(II110)),zeros(size(II120)),zeros(size(II130)),zeros(size(II140)),zeros(size(II150)),II160,II170]; ...
            [zeros(size(II210)),zeros(size(II220)),zeros(size(II230)),zeros(size(II240)),zeros(size(II250)),II260,II270]; ... 
            [zeros(size(II310)),zeros(size(II320)),zeros(size(II330)),zeros(size(II340)),zeros(size(II350)),II360,II370]; ...
            [zeros(size(II410)),zeros(size(II420)),zeros(size(II430)),zeros(size(II440)),zeros(size(II450)),II460,II470]; ...
            [zeros(size(II510)),zeros(size(II520)),zeros(size(II530)),zeros(size(II540)),zeros(size(II550)),II560,II570]; ... 
            [zeros(size(II610)),zeros(size(II620)),zeros(size(II630)),zeros(size(II640)),zeros(size(II650)),zeros(size(II660)),zeros(size(II670))]; ... 
            [zeros(size(II710)),zeros(size(II720)),zeros(size(II730)),zeros(size(II740)),zeros(size(II750)),zeros(size(II760)),zeros(size(II770))] ]);
        
        

        % Connective  prob. from PV L23 BC to L23 Pry: 32.9%.
        EI11 = double(unifrnd(0,1,num_bio_neurons,num_inneurons1)<32.9/100);
        % Connective  prob. from PV ChC to L23 Pry: 31.3%.
        EI12 = double(unifrnd(0,1,num_bio_neurons,num_inneurons2)<31.3/100);
        % Connective  prob. from SOM L23 MC to L23 Pry: 38.8%.
        EI13 = double(unifrnd(0,1,num_bio_neurons,num_inneurons3)<38.8/100);
        % Connective  prob. from SOM L23 BC to L23 Pry: 21.1%.
        EI14 = double(unifrnd(0,1,num_bio_neurons,num_inneurons4)<21.1/100);
        % Connective  prob. from SOM BTC to L23 Pry: 33.3%.
        EI15 = double(unifrnd(0,1,num_bio_neurons,num_inneurons5)<33.3/100);
        % Connective  prob. from VIP BTC to L23 Pry: 10.5%.
        EI16 = double(unifrnd(0,1,num_bio_neurons,num_inneurons6)<10.5/100);
        % Connective  prob. from VIP BPC to L23 Pry: 0%.
        EI17 = double(unifrnd(0,1,num_bio_neurons,num_inneurons7)<0/100);
        net.EI = (-net.in_weight_fix)*double([EI11,EI12,EI13,EI14,EI15,EI16,EI17]);
        net.EI0 = double(net.EI~=0);
        
        % Connective  prob. from L23 Pry to PV L23 BC: 15.9%.
        IE11 = double(unifrnd(0,1,num_inneurons1,num_bio_neurons)<15.9/100);
        % Connective  prob. from L23 Pry to PV ChC: 0%.
        IE21 = double(unifrnd(0,1,num_inneurons2,num_bio_neurons)<0/100);
        % Connective  prob. from L23 Pry to SOM L23 MC: 20.4%.
        IE31 = double(unifrnd(0,1,num_inneurons3,num_bio_neurons)<20.4/100);
        % Connective  prob. from L23 Pry to SOM L23 BC: 10.5%.
        IE41 = double(unifrnd(0,1,num_inneurons4,num_bio_neurons)<10.5/100);
        % Connective  prob. from L23 Pry to SOM BTC: 22.2%.
        IE51 = double(unifrnd(0,1,num_inneurons5,num_bio_neurons)<22.2/100);
        % Connective  prob. from L23 Pry to VIP BTC: 21%.
        IE61 = double(unifrnd(0,1,num_inneurons6,num_bio_neurons)<21/100);
        % Connective  prob. from L23 Pry to VIP BPC: 0%.
        IE71 = double(unifrnd(0,1,num_inneurons7,num_bio_neurons)<0/100);
        net.IE = net.ex_weight_fix*double([IE11;IE21;IE31;IE41;IE51;IE61;IE71]);
        net.IE0 = double(net.IE~=0);


        %% train network
        sim_train = {};

        for i = cur_iteration:num_train_sets

            iteration = net.iteration;
            
            if ( mod(iteration,save_interval) == 0 )&&(iteration>=2)
                net_sim = net;
                for j = 1:num_test_sets
                    net_sim.use_inhibition = true;
                    [sim_test{j},net_sim] = snn_simulate( net_sim, test_set{j}.data, 'collect', field_collectors );
                    [sim_free{j},net_sim] = snn_simulate( net_sim, free_run_data{j}.data, 'collect', field_collectors );
                end
                data_set.net = net;
                data_set.sim_train = sim_train;
                data_set.sim_test = sim_test;
                data_set.sim_free = sim_free;
                data_set.performance = performance;
                data_set.state = state;
                if show_fig
                    plot_data_set( data_set );
                end
                file_name = [ save_path, sprintf( 'data_set_%03d%05d.mat', epoch-1, iteration ) ];
                fprintf( 'saving results to: %s...\n', file_name );
                save( file_name, 'net', 'sim_train', 'sim_test', 'sim_free', 'all_seq_ids', ...
                      'performance', 'train_set_generator', 'free_set_generator', ...
                      'num_trials', 'seq_probs','state' );
            end
            
            iteration = iteration+1;

            if isempty( seq_ids )
                seq_id = find( cumsum(seq_probs) > rand(), 1 );
            else
                seq_id = seq_ids( mod(i-1,length(seq_ids))+1 );
            end
            [patterns,pat_sequences,~,~,~,concept,Ve_location] = generate_patterns1(stimulus,T/2,N_spacial,define);

            net.patterns = patterns;
            net.list = 1:length(stimulus);
            net.pat_sequences = pat_sequences;
            net.concept = concept;
            net.Ve_location = [net.Ve_location,Ve_location(:)];
            all_seq_ids( epoch, i ) = seq_id;
            train_set_generator.seq_id = seq_id;
            fprintf( '\niteration: %i\n', iteration );
 
            net.num_runs = num_runs;
            [net,sim_train] = snn_update_ct( net, [], ...
                                             'set_generator', train_set_generator, ...
                                             'collect', field_collectors );
           toc;
           num_trials( epoch, i ) = net.num_trials;

            net.num_runs = 1;

            sim_test = cell(num_seqs,1);
            sim_free = cell(num_seqs,1);

            
        end

        cur_iteration = 1;
        
    end
end