function [net,Z,P] = snn_sample_concept( net, data, ct )
net.update_on_spike = 1;
t = data.time(ct(1));
time_range = (data.time(ct(end))-data.time(ct(1)));% time_range is the time duration
num_spikes = max(floor(time_range*1000),size(net.patterns{1,1},2));
spike_times = (1:num_spikes)/1000;
net.w_rf = -5;
net.tau_rf = 0.01;
net.num_neurons = net.num_bio_neurons;
count = [0;0];
count1 = [0;0];
iden_t = (-1)*ones(length(net.stimulus),1);

DVA = [];
stability = [];
%% initial value of necessary variables
    Z_spikes = inf(net.num_bio_neurons,num_spikes); 
    a_Z = zeros(net.num_bio_neurons,1);

    l_spikes = zeros(net.num_inneurons,num_spikes);

    Z = zeros(net.num_bio_neurons, num_spikes, 'single');
    Z_spiking = zeros(net.num_bio_neurons, num_spikes, 'single');

    last_spikes_l = repmat(t, net.num_inneurons, 1);

    aZ = 0;

    last_spikes_X = repmat(t, net.num_inputs, 1);
    last_spikes_Z = repmat(t, net.num_bio_neurons, 1);
    
    hX = zeros(net.num_inputs, 2);
    hZ = zeros(net.num_bio_neurons, 2);
    hl = zeros(net.num_inneurons, 2);


    
    net.d_W = zeros(net.num_bio_neurons,net.num_inputs); % initial modifications of feedforward weights
    net.d_V = zeros(net.num_bio_neurons,net.num_bio_neurons); % initial modifications of lateral connection among ex. neurons

    P = zeros(net.num_bio_neurons, 1, 'single');
    net.At = zeros(2,num_spikes, 'single');
    A_v = zeros(1,num_spikes);
    A_w = zeros(1,num_spikes);
    %%
    i = 1;
    i_Z = 1;
    i_l = 1;
    %%
    action = 0;
    reward = 0;

     if ~isfield( net, 'groups' )
         net.groups = 0;
     end
     if ~isfield( net, 'alpha_w' )
         net.alpha_w = 1;
     end
    if ~isfield( net, 'alpha_v' )
        net.alpha_v = 1;
    end
    if ~isfield( net, 'w_temperature' )
        net.w_temperature = 1;
    end
    
    group_idx = [ 0, cumsum( net.groups ), net.num_bio_neurons ]; 
    net.num_o(:) = 0;
    %%
    try
       for j = 1:num_spikes % num_spikes is the number of all the time steps
           j0 = floor(j/(net.T));% j0 is the number of previous stimuli
           j1 = j - (j0*net.T);% j1 is the time step of the current stimulus
           t = spike_times(j);% t is the time at the current time step

           % synaptic currents, membrane potentials and spiking rates have
           % to be updated at each time step

           % update feedforward synapses
           % synaptic currents in exponential forms are updated with time
            while (i < size(data.Xt,2)) && (t > data.Xt(2,i)) % i is the time step
                 n_id = data.Xt(1,i);
                 spiking_t = data.Xt(2,i);
                 hX(n_id,1) = hX(n_id,1)*exp(-double(spiking_t-last_spikes_X(n_id))/net.tau_x_r) + 1;
                 hX(n_id,2) = hX(n_id,2)*exp(-double(spiking_t-last_spikes_X(n_id))/net.tau_x_f) + 1;
                 last_spikes_X(n_id) = spiking_t;
                 i = i+1;
            end
            hX(:,1) = hX(:,1).*exp(-double(t-last_spikes_X)/net.tau_x_r);
            hX(:,2) = hX(:,2).*exp(-double(t-last_spikes_X)/net.tau_x_f);
            d_hX = diff(hX,1,2);
            hX_all(:,j) = d_hX;

             % update lateral synapses of ex. neural group
             while (i_Z < size(Z_spikes,2)) && (t > i_Z/1000 ) %i_Z is the time step
                 spiking_t = i_Z/1000;
                 for n_id = 1:net.num_bio_neurons
                     if Z_spikes(n_id,i_Z) == 1
                        hZ(n_id,1) = hZ(n_id,1)*exp(-double(spiking_t-last_spikes_Z(n_id))/net.tau_z_r) + 1;
                        hZ(n_id,2) = hZ(n_id,2)*exp(-double(spiking_t-last_spikes_Z(n_id))/net.tau_z_f) + 1;
                        last_spikes_Z(n_id) = spiking_t;
                     end
                 end
                 i_Z = i_Z+1;
             end
             hZ(:,1) = hZ(:,1).*exp(-double(t-last_spikes_Z)/net.tau_z_r);
             hZ(:,2) = hZ(:,2).*exp(-double(t-last_spikes_Z)/net.tau_z_f);
             d_hZ = diff( hZ,1,2 );
             hZ_all(:,j) = d_hZ;

             % update lateral synapses of inhi. neural group
             while (i_l<size(l_spikes,2)) && (t > i_l/1000) %i_l is the time step
                 spiking_t = i_l/1000;
                 for n_id = 1:net.num_inneurons
                     if l_spikes(n_id,i_l) == 1
                        hl(n_id,1) = hl(n_id,1)*exp(-double(spiking_t -last_spikes_l(n_id))/net.tau_z_r) + 1;
                        hl(n_id,2) = hl(n_id,2)*exp(-double(spiking_t -last_spikes_l(n_id))/net.tau_z_f) + 1;
                        last_spikes_l(n_id) = spiking_t;
                     end
                 end
                 i_l = i_l+1;
             end

             hl(:,1) = hl(:,1).*exp(-double(t-last_spikes_l)/net.tau_z_r);
             hl(:,2) = hl(:,2).*exp(-double(t-last_spikes_l)/net.tau_z_f);
             d_hl = diff( hl,1,2 );
             hl_all(:,j) = d_hl;
           %%
            % all the synaptic currents are reset to be 0 after absence of each stimulus

            if (j1 == 0)&&(j > net.T)
                hX = zeros(net.num_inputs,2);
                hZ = zeros(net.num_bio_neurons,2);    
                hl = zeros(net.num_inneurons,2);    
                last_spikes_Z(:) = t;
                Z_spiking(:,j) = 0;
                Z(:,j) = 0;
            end
             
            %% plastic weights are limited in the range if necessary
            net.W = min(1,max(0.00001,net.W)).*net.W0;
            net.V = min(1,max(0.00001,net.V)).*net.V0;
            %% update membrane potential and draw spikes
             
             % update ex. neural membrane potential and draw spikes
             % inhi. inputs and ex. inputs
             % influnce of VIP inhi. neurons
             % consider responses of VIP inhi. neurons
             UZ_ei = double(net.EI.*net.EI0)*d_hl;
             UZ_ee = net.w_temperature*net.W*d_hX + net.V*d_hZ;
             
             UZ = UZ_ee + UZ_ei;
             [PZ_t,AZ_t] = wta_softmax2( UZ );

             % influnce of refractory periods
             % no spikes are induced during refractory periods
             PZ_t = PZ_t.*double(sum(Z(:,max(j-net.ex_delay,j1):max(j-1,j1)),2) == 0);
             % draw spikes from softmax distributions
             [Z_j,K] = wta_draw_k2(PZ_t,Z,j);
             Z(:,j) = Z_j(:);Z_spikes(:,j) = Z_j(:);
             aZ = max(aZ,size(K,1));
             if (~isempty(K))
                 for n_k = 1:size(K,1)
                     k1 = K(n_k);
                     if Z_j(k1) == 1
                     last_spikes_Z(k1) = t;
                     end
                 end
             end
             % Z_spiking is the neural spiking rates induced by presented stimulus
             if j1 >= 1
                Z_spiking(:,j) = (Z_spiking(:,max(j0*net.T+1,j-1)) + Z(:,max(j0*net.T+1,j-1)))*exp(-1/20);
             else
                Z_spiking(:,j) = 0;
             end
             
            
             % update inhi. neural membrane potential and draw spikes
             Ul_ie = double(net.IE.*net.IE0)*d_hZ + (net.VIP(:))*rand(1)*(5*double((j1 >= net.T/2)&&(j > net.T)));
             Ul_ii = double(net.II.*net.II0)*d_hl;
             Ul = Ul_ie + Ul_ii;
             % influnce of refractory periods
             % no spikes are induced during refractory periods
             Pl(:,j) = net.I_firingrate*Ul.*double(Ul>0).*double(sum(l_spikes(:,max(j1,j - net.inhi_delay):max(j1,j-1)),2) == 0);
             l_spikes(:,j) = double(random('Poisson',Pl(:,j))>0);
             j0 = floor(j/(net.T));j1 = j-(j0*net.T);
             if ((j > net.T)&&(j > (j0*(net.T)))&&((j1 == (net.T-1))))
                 clear L_VIP_spikes;
                 % [j1,j0*(net.T)+(net.T)/2,j]
                 L_VIP_spikes = l_spikes(find(net.VIP(:)==1),(j0*(net.T)+(net.T)/2):j);
                 sum(L_VIP_spikes(:))
             end

            %% Update clustering sets
             % j0 is the number of previous stimuli and j1 is the time step of the current stimulus
             j0 = floor(j/(net.T));j1 = j-(j0*net.T);
             % during noisy durations, no identifications or rewards are considered
             if (j1<net.t_start)&&(j>(j0*(net.T))) 
                   action = 0;reward = 0;
             end
             % on stimulus onset, both identifications and rewards are reset
             if j1 == (net.T)/2 
                 action = 0;reward = 0;ident0 = 0; % iden_t0 is reset to mark the time of the first correct identification
             end
             if ((j > net.T)&&(j > (j0*(net.T)))&&(j1 >= net.t_start))||(j == num_spikes) % with stimulus presented
               observe_size = 1;
               clear observe;
               observe = [Z(:,j+1-observe_size:j);Z_spiking(:,j)];
               % temporal observe sensory data includes both neural
               % spikes and rates
               observe = observe(:,find(sum(observe)>0));

               %% Update blank clustering sets
               % Add induced neural responses into blank clustering sets
               if (j1<(net.t_start))&&(j0 <= size(net.action,2) + 1)
                 for ii = 1:size(net.n_clu_merged,2)
                  for jj = 1:net.N_concept
                  if (sum(sum(net.n_clu_merged(jj,ii))) == 0)&&(~isempty(observe))
                     net.action{jj,ii} = [net.action{jj,ii},observe];
                     net.action{jj,ii} = net.action{jj,ii}(:,find(sum(net.action{jj,ii})>0));
                     if size(net.action{jj,ii},2)>net.cluster_size
                        net.action{jj,ii} = net.action{jj,ii}(:,end-net.cluster_size+1:end);
                     end
                  end
                 end
                end
               end
               %% likelihoods for identification
                 N_concept = net.N_concept;
                 if (~isempty(observe))&&(j1 >= net.T/2)&&(net.concept(1,ceil(j/(net.T)))>0)&&(j < num_spikes)
                    % With non-blank neural responses, and stimuli presented, identifications are made
                    % rewards depend on identifications of concept
                    if reward == 0
                     p = zeros(N_concept,2);
                     p = probability_equaldistribution_clustering1(observe,net.action,p,net.beta,net.Repeat,net.N_concept,net.N_state);
                     % determine whether types determined by the concept are same
                     for nn = 1:N_concept % For each concept, action indicates the identification of its state.
                         clear aa1;clear aa2;
                         aa1 = p(nn,:);
                         action(1,nn) =  find(aa1 == max(aa1),1);% action(1,nn) is the identification of the nn th concept
                     end
                     clear c;clear c0;reward0 = 1;
                     for nn = 1:N_concept % For each concept, if the action is equal to the value of the concept, it is the correct identification.
                         reward0 = reward0 * double(action(nn) == net.concept(nn,ceil(j/(net.T)))) * double(j1 < net.T);
                     end
                     reward = reward0;% If identifications of all the concepts are correct within the presented duration, the network will receive a possitive reward.
                     
                     if (reward == 1)&&(net.concept(1,ceil(j/(net.T)))>0)
                         ident0 = max(1,j1-(net.T)/2); % iden_t0 is the time of the first correction identification
                         iden_t(ceil(j/(net.T))-1,1) = ident0;
                         % show of simulating process if necessary
                         fprintf('\n');
                         clear aa;
                         aa = ['Judgement duration of Situation ',num2str(net.concept(1,ceil(j/(net.T)))),' is ',num2str(ident0), ' time step(s).'];
                         disp(aa);
                         fprintf('\n');
                     end
                    end  
                 end

            %% update the clustering set 
              if (~isempty(observe))&&(j1 == (ident0 + (net.T)/2))&&(min(action(:)) ~= 0)&&(reward == 1)&&(net.concept(1,ceil(j/(net.T)))>0)&&(j < num_spikes)&&(net.learning == 1)
                         for nn1 = 1:net.N_concept
                             net.action{nn1,action(nn1)} = [net.action{nn1,action(nn1)},observe];
                             net.action{nn1,action(nn1)} = net.action{nn1,action(nn1)}(:,find(sum(net.action{nn1,action(nn1)})>0));
                             if size(net.action{nn1,action(nn1)},2)>net.cluster_size
                                 net.action{nn1,action(nn1)} = net.action{nn1,action(nn1)}(:,end-net.cluster_size+1:end);          
                             end 
                         end
              end
            %% synaptic weight updates (STDP)
             % STDP is controlled by reward
             if  (reward == 1)&&(net.concept(1,ceil(j/(net.T)))>0)&&(j < num_spikes)&&(net.learning == 1)
              eta = net.eta;
              % feedforward weights
              net.W = min(1,max(0.00001,net.W));
              for n_k = 1:size(Z,1)
                  clear W_d;
                  W_d = 1-1./net.W(n_k,:) + 1./(exp(net.W(n_k,:))-1);
                  clear d_W_k1;clear d_W_k2;clear d_W_k;
                  d_W_k1 = Z(n_k,(j+1-observe_size):j).*(net.delayparameter.^(j-((j+1-observe_size):j)));
                  d_W_k2 = net.w_temperature*(hX_all(:,(j+1-observe_size):j))'-ones(j-(j+1-observe_size)+1,1)*W_d;
                  d_W_k = (eta*d_W_k1*d_W_k2)./max(eta*ones(size(W_d)),W_d);
                  net.W(n_k,:) = net.W(n_k,:) + d_W_k;
                  net.W(n_k,:) = min(1,max(0.00001,net.W(k1,:)));
              end
              net.W = min(1,max(0.00001,net.W)).*net.W0;
              
              %  latent weights
              net.V = min(1,max(0.00001,net.V)).*net.V0;
              for n_k = 1:size(Z,1)
                  clear V_d;
                  V_d = 1-1./net.V(n_k,:) + 1./(exp(net.V(n_k,:))-1);
                  clear d_V1;clear d_V2;
                  d_V1 = Z(n_k,(j+1-observe_size):j).*(net.delayparameter.^(j-((j+1-observe_size):j)));
                  d_V2 = (hZ_all(:,(j+1-observe_size):j))'-ones(j-(j+1-observe_size)+1,1)*V_d;
                  d_V_k = (eta*d_V1*d_V2)./max(eta*ones(size(V_d)),V_d);
                  net.V(n_k,:) = net.V(n_k,:) + d_V_k;
                  net.V(n_k,:) = min(1,max(0.00001,net.V(n_k,:)));
              end
              for nn = 1:net.num_bio_neurons
                 net.V(nn,nn) = 0;
              end
              net.V = min(1,max(0.00001,net.V)).*net.V0;

             end
             
             if (j1 <= 1)&&(j>net.T)
                 hX = zeros(net.num_inputs,2);   
                 hZ = zeros(net.num_bio_neurons,2);     
                 hl = zeros(net.num_inneurons,2);
                 Z_spiking(:,j) = 0;
                 d_hX = diff(hX,1,2);
                 d_hZ = diff( hZ,1,2);
                 d_hl = diff(hl,1,2);

                 last_spikes_Z(:) = t;
                 last_spikes_l(:) = t;

             end
             
             end
       end
        
        
        
        
    catch
           fprintf('There has been an error, while sampling!\nExcluding run from training\n');
           file_name = sprintf('/tmp/error_data_%u_%04u.mat', net.iteration, round(9999*rand()) );
           the_error = lasterror();
           fprintf( '\n%s\n', the_error.message );
           fprintf( '  in %s on line %i\n\n', the_error.stack(1).name, the_error.stack(end).line );
           fprintf('saving workspace to: %s\n', file_name);
           save( file_name );
           
           net.R = -100000;
           fprintf('pausing 10 seconds...\n');
           pause(1);
           return;
    end
    
    
    net.Z_spikes = Z_spikes(:,i_Z:end);
    net.R = mean( net.At(1,:) );
    net.A_v = A_v;
    net.A_w = A_w;
    
    net.hX = hX;
    net.hZ = hZ;
    
    net.ex_spike_train = Z;
    net.in_spike_train = l_spikes;


    count = count(1:net.N_concept,1);
    count1 = count1(1:net.N_concept,1);
    net.count = [net.count,count];
    net.total_count = [net.total_count,count1];
    if (net.learning ~= 1)
       net.iden_t = [net.iden_t,iden_t];% iden_t is the reaciton time and recorded
    end
    if (net.learning == 1)
     for nn1 = 1:net.N_concept
        for nn2 = 1:net.N_state
            [DVA(nn1,nn2),stability(nn1,nn2)] = DVA_neuralspike(net.action{nn1,nn2});
        end
     end 
     net.stability = [net.stability,stability(:)];
    end
    
%%
end