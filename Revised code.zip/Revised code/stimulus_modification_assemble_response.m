function stimulus_modification_assemble_response(N_situation,N_assemble,rate,assembles)
clear Z_responses;
for nn = 1:N_situation
    clear Zleft_responses0;
    Zleft_responses0 = rate(:,:,:,nn);
    Z_responses(:,nn) = mean(mean(Zleft_responses0,2),3);
end

clear MI;figure;
MI = (Z_responses(:,1) - Z_responses(:,2))./(Z_responses(:,1) + Z_responses(:,2));
[a0,b0] = hist(MI_assemble{n1,1}(:));
a1 = a0./sum(a0);



MI_assemble = cell(N_assemble,1);figure;
for n1 = 1:N_assemble
    clear neurons;clear Z_assemble_responses;
    neurons = assembles{n1,1};
    Z_assemble_responses = Z_responses(neurons,:);
    MI_assemble{n1,1} = (Z_assemble_responses(:,1) - Z_assemble_responses(:,2))./(Z_assemble_responses(:,1) + Z_assemble_responses(:,2));
    [a0,b0] = hist(MI_assemble{n1,1}(:));
    a1 = a0./sum(a0);
    subplot(1,3,n1);bar(b0,a1,'Facecolor',[0.5,0.5,0.5]);ylim([0,1.1*max(a1(:))]);hold on;
end
end