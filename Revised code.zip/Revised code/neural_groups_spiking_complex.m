function [popucomplex_sti1,popucomplex_pre1] = neural_groups_spiking_complex(spike_sti,spike_pre)
N_neuron = size(spike_sti,1);
N_simulation = size(spike_sti,3);
N_situation = size(spike_sti,4);
Zright_complex_pre0 = zeros(N_simulation,N_situation,N_neuron);
Zright_complex_sti0 = zeros(N_simulation,N_situation,N_neuron);
for n1 = 1:N_situation
 for n2 = 1:N_neuron
    for n3 = 1:N_simulation
        clear spikes;
        spikes = spike_sti(n2,:,n3,n1);
        [C1, H] = calc_lz_complexity(spikes, 'exhaustive', 1);
        Zright_complex_sti0(n3,n1,n2) = C1;
        clear spikes;
        spikes = spike_pre(n2,:,n3,n1);
        [C2, H] = calc_lz_complexity(spikes, 'exhaustive', 1);
        Zright_complex_pre0(n3,n1,n2) = C2;
    end
 end
end
clear popucomplex_sti1;clear popucomplex_pre1;
popucomplex_sti1 = mean(mean(Zright_complex_sti0,3),1);
popucomplex_pre1 = mean(mean(Zright_complex_pre0,3),1);
end